# Weather illustration — small motion refinement

This patch changes only `Weather/weather-view.js` and only the existing weather painter.

## Included
- Clouds drift gently with the wind direction.
- Rain slants and travels with the wind; water-ripple animation stays in place.
- Snowfall receives a subtle wind drift.
- Mist moves slowly across the scene.
- The existing foreground pine has a very small wind sway.

## Deliberately unchanged
- The shared Japanese landscape and its composition.
- Full-bleed, edge-to-edge Weather scene: no frame or border is added.
- Portrait layout and the existing Landscape-only crop.
- Live Art and its separate card/replay behaviour.
- Weather data, screen layout, typography, and feature navigation.

## Apply locally
1. Extract this ZIP into the root of your repository (the folder that contains `Weather/`).
2. Run `python3 apply_weather_refinement.py` from that repository root.
3. The script checks every original code block before making any edit. It stops without changing anything if the source differs from the inspected version.
4. A `.bak` backup of `Weather/weather-view.js` is created alongside the original.

This is a local patch only. It does not write to GitHub or deploy the app.

Suggested commit title after you review and upload the change:
`Refine wind-responsive Weather illustration motion`
