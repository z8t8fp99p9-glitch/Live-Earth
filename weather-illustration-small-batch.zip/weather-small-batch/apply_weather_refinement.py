#!/usr/bin/env python3
"""Apply the small Weather illustration motion refinement to a local repo copy."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

REPLACEMENTS = [
    (
        "cloud drift",
        """      const cloudCount=state.cloud>78?2:state.cloud>43?1:0;
      for(let i=0;i<cloudCount;i++){
        const x=width*(.42+i*.25)+Math.sin(t*.10+i)*Math.max(1.5,state.wind*.22);
        const y=height*(.25+i*.075);
        const scale=Math.min(width,height)*(.050+i*.008);""",
        """      const cloudCount=state.cloud>78?2:state.cloud>43?1:0;
      const windX=-Math.sin(state.direction*Math.PI/180);
      const cloudDrift=.012+Math.min(1,state.wind/45)*.028;
      for(let i=0;i<cloudCount;i++){
        const scale=Math.min(width,height)*(.050+i*.008);
        const travel=width+scale*3;
        const baseX=width*(.42+i*.25);
        const x=((baseX+t*width*cloudDrift*windX+scale*1.5)%travel+travel)%travel-scale*1.5;
        const y=height*(.25+i*.075);""",
    ),
    (
        "gentle pine sway",
        """      const tx=width*.13,ty=height*.84,sc=Math.min(width,height)*.31;
      ctx.translate(tx,ty);ctx.scale(sc/100,sc/100);""",
        """      const tx=width*.13,ty=height*.84,sc=Math.min(width,height)*.31;
      const sway=reduced?0:Math.sin(t*.72)*Math.min(2.4,state.wind*.055);
      ctx.translate(tx+sway,ty);ctx.scale(sc/100,sc/100);""",
    ),
    (
        "wind-driven snow",
        """    function drawSnow(p,t){if(state.weather!=='snow'){snowLoad=Math.max(0,snowLoad-.0015);return;}const {soft}=p;const amount=Math.max(.12,Math.min(1,state.snowfall/2));snowLoad=reduced?Math.max(snowLoad,amount*.32):Math.min(.92,snowLoad+amount*.00055);const count=Math.round(7+amount*9);for(let i=0;i<count;i++){const x=((i*83+Math.sin(t*.3+i)*13)%width+width)%width;const y=((i*47+t*(4+(i%4)*1.2))%height*.78);ctx.save();ctx.globalAlpha=.45+(i%3)*.12;ctx.fillStyle=soft;ctx.beginPath();ctx.arc(x,y,1+(i%3)*.45,0,Math.PI*2);ctx.fill();ctx.restore();}}""",
        """    function drawSnow(p,t){
      if(state.weather!=='snow'){snowLoad=Math.max(0,snowLoad-.0015);return;}
      const {soft}=p;
      const amount=Math.max(.12,Math.min(1,state.snowfall/2));
      snowLoad=reduced?Math.max(snowLoad,amount*.32):Math.min(.92,snowLoad+amount*.00055);
      const windX=-Math.sin(state.direction*Math.PI/180);
      const drift=windX*Math.min(4.5,state.wind*.11);
      const count=Math.round(7+amount*9);
      for(let i=0;i<count;i++){
        const x=((i*83+Math.sin(t*.3+i)*13+t*drift)%width+width)%width;
        const y=((i*47+t*(4+(i%4)*1.2))%height*.78);
        ctx.save();ctx.globalAlpha=.45+(i%3)*.12;ctx.fillStyle=soft;
        ctx.beginPath();ctx.arc(x,y,1+(i%3)*.45,0,Math.PI*2);ctx.fill();ctx.restore();
      }
    }""",
    ),
    (
        "wind-driven rain",
        """    function drawRain(p,t){if(state.weather!=='rain'&&state.weather!=='storm')return;const {soft,ink}=p;const intensity=Math.min(1,Math.max(.18,state.precipitation/6));const count=Math.round(6+intensity*5);for(let i=0;i<count;i++){const x=((i*73+t*(state.wind*.8+9))%width+width)%width;const y=((i*49+t*(90+intensity*90))%height*.86);line([[x,y],[x-2+Math.sin(state.direction*Math.PI/180)*6,y+8+intensity*7]],soft,.23+intensity*.18,.65);}
      for(let i=0;i<3;i++){const x=width*(.18+i*.31);const y=height*(.75+(i%2)*.12);const phase=(t*.55+i*.27)%1;ctx.save();ctx.globalAlpha=.32*(1-phase);ctx.strokeStyle=ink;ctx.lineWidth=.75;ctx.beginPath();ctx.ellipse(x,y,4+phase*15,1.5+phase*3,0,0,Math.PI*2);ctx.stroke();ctx.restore();}}""",
        """    function drawRain(p,t){
      if(state.weather!=='rain'&&state.weather!=='storm')return;
      const {soft,ink}=p;
      const intensity=Math.min(1,Math.max(.18,state.precipitation/6));
      const windX=-Math.sin(state.direction*Math.PI/180);
      const count=Math.round(8+intensity*7);
      for(let i=0;i<count;i++){
        const x=((i*73+t*(4+state.wind*.55)*windX)%width+width)%width;
        const y=((i*49+t*(90+intensity*90))%height*.86);
        const lean=windX*Math.min(6,1.2+state.wind*.13);
        line([[x,y],[x+lean,y+8+intensity*7]],soft,.23+intensity*.18,.65);
      }
      for(let i=0;i<3;i++){
        const x=width*(.18+i*.31);const y=height*(.75+(i%2)*.12);
        const phase=(t*.55+i*.27)%1;
        ctx.save();ctx.globalAlpha=.32*(1-phase);ctx.strokeStyle=ink;ctx.lineWidth=.75;
        ctx.beginPath();ctx.ellipse(x,y,4+phase*15,1.5+phase*3,0,0,Math.PI*2);ctx.stroke();ctx.restore();
      }
    }""",
    ),
    (
        "wind-carried mist",
        """    function drawFog(p,t){if(state.weather!=='fog'&&state.cloud<85)return;const {paper,soft}=p;for(let i=0;i<3;i++){const y=height*(.49+i*.075)+Math.sin(t*.15+i)*7;const g=ctx.createLinearGradient(0,y,width,y);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.48,state.weather==='fog'?'rgba(238,238,224,.34)':'rgba(238,238,224,.15)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.save();ctx.fillStyle=g;ctx.fillRect(0,y-9,width,19);ctx.restore();}}""",
        """    function drawFog(p,t){
      if(state.weather!=='fog'&&state.cloud<85)return;
      const driftX=-Math.sin(state.direction*Math.PI/180);
      const driftRange=Math.max(1,width*.08);
      for(let i=0;i<3;i++){
        const y=height*(.49+i*.075)+Math.sin(t*.15+i)*7;
        const offset=((t*(.45+state.wind*.025)*driftX)%driftRange+driftRange)%driftRange-driftRange/2;
        const g=ctx.createLinearGradient(0,y,width,y);
        g.addColorStop(0,'rgba(255,255,255,0)');
        g.addColorStop(.48,state.weather==='fog'?'rgba(238,238,224,.34)':'rgba(238,238,224,.15)');
        g.addColorStop(1,'rgba(255,255,255,0)');
        ctx.save();ctx.fillStyle=g;ctx.fillRect(-driftRange/2+offset,y-9,width+driftRange,19);ctx.restore();
      }
    }""",
    ),
]


def apply(root: Path) -> None:
    target = root / "Weather" / "weather-view.js"
    if not target.is_file():
        raise FileNotFoundError(f"Expected file not found: {target}")
    source = target.read_text(encoding="utf-8")

    # Validate the complete batch before writing anything.
    for label, old, _new in REPLACEMENTS:
        count = source.count(old)
        if count != 1:
            raise RuntimeError(
                f"Cannot safely apply '{label}': expected one exact match, found {count}. "
                "No files were changed. Check that the file matches the inspected main-branch version."
            )

    updated = source
    for _label, old, new in REPLACEMENTS:
        updated = updated.replace(old, new, 1)

    backup = target.with_suffix(target.suffix + ".before-weather-refinement.bak")
    if backup.exists():
        raise FileExistsError(f"Backup already exists: {backup}; no files were changed.")
    backup.write_text(source, encoding="utf-8")
    target.write_text(updated, encoding="utf-8")
    print(f"Updated: {target}")
    print(f"Backup:  {backup}")
    print(f"Applied {len(REPLACEMENTS)} focused motion refinements.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Repository root (defaults to current folder)")
    args = parser.parse_args()
    try:
        apply(args.root.resolve())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
