LIVE // EARTH — Six Data Worlds: Direct Universal Architecture

Upload this ZIP unchanged to the repository root using the existing ZIP auto-extractor. Do not unzip it.

Commit title: Connect six Data Worlds directly to universal Earth systems

Changes:
- Each of the six Data World controllers owns its view canvas, scene, camera, renderer and cleanup, and calls the existing Earth Engine API directly.
- Removes the extra EarthEngine/Views/independent-world-globe.js helper.
- Keeps the Universal Grid System and GPU Grid Skin as the shared numerical-grid pipeline.
- The five worlds without connected grid adapters load the same universal APIs and wait for verified dataset adapters; no placeholder measurements are shown.
- Atmosphere remains the first verified consumer of the Universal Grid System and GPU Grid Skin.
- Earth Activity requires a point/event renderer, not a continuous grid.
- Updates service-worker precache and cache version for the shared grid files.
- Does not modify EarthEngine/Core/earth-engine.js, Home or Earth View.

Important: This patch establishes the shared architecture and globe ownership. It does not claim all six datasets are already rendered.
