# LIVE // EARTH — Weather Live Art Rain/Clear state fix

## Exact target
- Repository: `z8t8fp99p9-glitch/Live-Earth`
- Branch: `main`
- Inspected base commit: `f48ca9d078b334244c20d3ddd7176d4c303f5842`
- Target file: `Weather/Art/live-art-online.js`
- Inspected file blob: `8e8fd3dd83f5edf9999e5c4d3aa4e592a516db79`

## Change
Add the missing module-local declaration directly after `let currentArtId = '';`:

```js
let currentWeather = '';
```

The renderer is wrapped in strict mode and currently assigns to `currentWeather` in `showPaper()`, `loadForWeather()`, `attachScreen()` and cleanup without declaring it. A strict-mode reproduction throws `ReferenceError: currentWeather is not defined`.

## Apply
From a local checkout at the inspected base commit, run:

```sh
git apply Weather-Live-Art-currentWeather-fix.patch
node --check Weather/Art/live-art-online.js
```

Then inspect the diff and commit the one-line change. This patch is intentionally not an auto-extractor upload ZIP; it is a reviewable patch for the existing source file.

## Commit title
`Fix Weather Live Art Weather-State Initialization`

## Validation already performed during inspection
- Confirmed the strict-mode renderer has 5 `currentWeather` assignments and no declaration.
- Confirmed Rain catalogue record, Rain asset ID, Rain weather tag and 153 ordered paths match.
- Confirmed Clear catalogue record, Clear asset ID, Clear weather tag and 757 ordered paths match.
- Confirmed `sw.js` imports `Weather/Art/service-worker-extension.js`.

## After applying
Test in the deployed app in this order:
1. Open Weather with internet enabled and select RAIN. Confirm `A Rainy Tea Afternoon` appears and paints progressively.
2. Tap Replay and confirm Rain paints again.
3. Select CLEAR. Confirm the Clear pavilion scene appears and paints progressively.
4. Switch back to RAIN. Confirm Rain is loaded again rather than leaving the Clear scene visible.

No artwork JSON, catalogue, Weather layout, 10:7 card, Replay UI, service worker or other app view is changed by this one-line fix.
