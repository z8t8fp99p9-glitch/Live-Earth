# Rendering architecture correction

## Responsibilities

- **Earth Engine** supplies the reusable globe.
- **Universal Grid System** loads and normalizes grid datasets.
- **GPU Grid Renderer / Skin** is dataset-agnostic. It converts scalar values to a texture, samples a caller-supplied colour-ramp texture, and optionally draws generic interval contours. It contains no dataset IDs, unit checks, temperature palettes, or scientific assumptions.
- **Atmosphere View Controller** owns Atmosphere-specific display decisions: temperature colour stops, Celsius range, 5 °C contour interval, contour colour, opacity, and related view presentation.
- Other View Controllers supply their own visualization options. They do not require edits to the shared renderer.

## Files in this package

`EarthEngine/Graphics/earth-grid-gpu-skin.js` is a complete replacement for the shared GPU renderer. Replace the existing file with this version.

Apply `patches/atmosphere-view-controller.js.patch` to `Atmosphere/atmosphere-view-controller.js`. This moves the temperature ramp and temperature contour interval into the Atmosphere View Controller and passes them through generic renderer options.

No global renderer code branches on dataset identity or units. The renderer's default ramp is a neutral fallback only; views should provide their own visualization configuration.
