# LIVE // EARTH — Universal Collector Fix Package

Prepared against repository `z8t8fp99p9-glitch/Live-Earth`, main branch audit
from 18 November 2026.

## Included

- `Data/Universal/engine/collector.py`: complete replacement.
  - Keeps each dataset isolated.
  - Records all successes, skips and failures.
  - Continues through all enabled datasets.
  - Writes a GitHub Actions step summary.
  - Updates each dataset's registry health state after the run.
  - Exits non-zero only after all datasets have been attempted.
- `Data/Universal/engine/bootstrap.py`: complete replacement.
  - Keeps success/failure status between hourly runs.
  - Uses correct cadence metadata for GFS, daily sources and event feeds.
- `patches/native_sources.py.patch`:
  - Adds cadence-aware skip logic for daily/hourly native sources.
  - Retries after a failed latest run.
  - Changes NASA POWER requests from the full 1981-to-present archive to a
    14-day recent window, while retaining 1981 as the historical lower boundary.
- `patches/atmosphere_gfs.py.patch`:
  - Skips only if the current cycle exists in the published Atmosphere manifest
    and both referenced raw files are present.
  - Old normalized rows from the previous adapter cannot suppress a new publish.
- No GPU renderer patch is included. The global GPU Grid Renderer must remain dataset-agnostic.
- `.gitignore`: excludes Python bytecode and local scientific source downloads.
- `patches/live-earth-scientific-refresh.yml.patch`: removes previously tracked `__pycache__` folders before staging, because `.gitignore` alone cannot untrack committed bytecode.

## Rendering architecture correction

The GPU Grid Renderer is shared infrastructure. It must not inspect dataset IDs,
choose temperature palettes, or apply temperature-specific contour rules. Those
settings belong to `Atmosphere/atmosphere-view-controller.js` (the Atmosphere
View Controller). Other views own their own visualization settings. The renderer
may expose generic rendering inputs, but the view supplies the palette, range,
opacity and contour configuration. This collector package does not modify either
view rendering file.

## Important behaviour

The existing workflow already uses `continue-on-error: true` for the collector,
commits successful data after the collector finishes, and then fails the job
when any dataset failed. That ordering is intentionally preserved.

The NASA POWER 1981 date is a historical coverage boundary, not the start date
for every hourly request. The collector asks for a recent bounded window and
selects the newest valid date returned for each sample location.

## Apply and test

1. Review the changed files in a test branch or local checkout.
2. Apply the three remaining `.patch` files from the repository root with `git apply`.
3. Run Python compilation:
   `python -m compileall -q Data/Universal/engine`
4. Run the collector workflow manually.
5. Confirm all five Atmosphere IDs appear in the manifest with the same
   current GFS cycle before considering the Atmosphere cutover complete.
6. Keep visualization changes in each View Controller; do not add dataset-specific
   branches to the shared GPU renderer.

No GitHub repository files were changed by preparing this package.

## Rendering architecture update (v3)

This package now includes a complete replacement for `EarthEngine/Graphics/earth-grid-gpu-skin.js` and a patch for `Atmosphere/atmosphere-view-controller.js`.

1. Replace the existing GPU grid skin file with the package version at `EarthEngine/Graphics/earth-grid-gpu-skin.js`.
2. Apply `patches/atmosphere-view-controller.js.patch` from the repository root.
3. The Atmosphere View Controller supplies its temperature palette and 5 °C contour interval. The shared renderer receives only generic color-stop and contour options; it does not inspect dataset IDs or units.

The renderer supports color stops as `[position, red, green, blue]` values normalized to 0–1, plus optional `contourInterval`, `contourStrength`, and `contourColor` options. If a view omits `colorStops`, a neutral generic fallback ramp is used.

## Rendering architecture update (v3)

This package now includes a complete replacement for `EarthEngine/Graphics/earth-grid-gpu-skin.js` and a patch for `Atmosphere/atmosphere-view-controller.js`.

1. Replace the existing GPU grid skin file with the package version at `EarthEngine/Graphics/earth-grid-gpu-skin.js`.
2. Apply `patches/atmosphere-view-controller.js.patch` from the repository root.
3. The Atmosphere View Controller supplies its temperature palette and 5 °C contour interval. The shared renderer receives only generic color-stop and contour options; it does not inspect dataset IDs or units.

The renderer supports color stops as `[position, red, green, blue]` values normalized to 0–1, plus optional `contourInterval`, `contourStrength`, and `contourColor` options. If a view omits `colorStops`, a neutral generic fallback ramp is used.
