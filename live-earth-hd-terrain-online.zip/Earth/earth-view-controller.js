/* LIVE // EARTH — Earth View Controller.
   Owns the full-screen Earth View lifecycle, controls and camera.
   Surface-anchored drag and pinch zoom are owned by this view. */
(() => {
  "use strict";
  if (window.__liveEarthEarthRendererInstalled) return;

  /*
   * EARTH VIEW ORGANISATION MAP
   * This remains one view-owned controller, following the numbered-section
   * convention established by Atmosphere. Sections group related responsibilities;
   * they are not separate modules and do not introduce new runtime features.
   *
   * FUTURE EXTENSION RULES
   * - Keep the base globe, camera, gestures and view lifecycle independent of layers.
   * - Keep data acquisition/validation separate from GPU preparation and rendering.
   * - Use the appropriate renderer for each family: surface skins, terrain/3D
   *   geometry, vectors/traffic, or points/events. Do not force every feature
   *   into a surface texture.
   * - Give every future layer explicit attach, update, remove and dispose ownership.
   * - Load optional data and heavy assets only when requested; never make them
   *   prerequisites for opening the clean Earth globe.
   * - Reuse the shared Earth Engine factory; do not borrow Prime Earth's scene,
   *   camera, renderer or layer registry.
   *
   * The rules above are architectural guidance only. No future feature or layer
   * system is implemented by this organisation pass.
   */

  const STYLE_ID = "le-independent-earth-view-style";
  // 01 — View configuration and stable identifiers.
  const STAGE_ID = "le-ev-stage";
  const QUALITY_KEY = "liveEarthQuality";
  const FOV = 34;
  const TARGET_DIAMETER = 1.34;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const reducedMotion = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;

  const style = document.createElement("style");
  // 02 — View-owned presentation foundation: stage, quality controls and Scanner.
  style.id = STYLE_ID;
  style.textContent = `
    #le-sky-view .le-ev-stage{position:absolute;z-index:2;inset:0;overflow:hidden;touch-action:none;background:transparent}
    #le-sky-view .le-ev-canvas{display:block;width:100%;height:100%;outline:none;touch-action:none;-webkit-tap-highlight-color:transparent}
    #le-quality-controls{position:fixed;z-index:12;left:50%;bottom:calc(env(safe-area-inset-bottom) + 139px);transform:translateX(-50%);display:flex;align-items:center;justify-content:center;gap:10px;padding:6px;border:1px solid rgba(210,240,255,.26);border-radius:999px;background:linear-gradient(145deg,rgba(255,255,255,.15),rgba(16,34,54,.72) 48%,rgba(0,5,15,.76));box-shadow:inset 1px 1px 2px rgba(255,255,255,.25),inset -2px -3px 6px rgba(0,0,0,.45),0 8px 24px #0008;backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);pointer-events:auto}
    #le-quality-controls[hidden],#le-location-scanner[hidden]{display:none}
    #le-quality-controls button{touch-action:manipulation}
    .le-quality-button{min-width:78px;padding:10px 13px;border-radius:999px;border:1px solid rgba(197,230,255,.24);color:#cfe8f8;background:rgba(255,255,255,.045);font:650 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;letter-spacing:.09em;text-transform:uppercase;-webkit-tap-highlight-color:transparent}
    .le-quality-button[aria-pressed="true"]{color:#f5fcff;border-color:rgba(153,226,255,.8);background:linear-gradient(135deg,rgba(102,204,255,.25),rgba(255,255,255,.1));box-shadow:inset 1px 1px 2px #ffffff50,0 0 14px rgba(71,187,255,.22)}
    .le-quality-button:active,.le-zoom-button:active{transform:scale(.96)}
    .le-zoom-button{width:38px;height:38px;display:grid;place-items:center;border-radius:50%;border:1px solid rgba(197,230,255,.28);color:#edf9ff;background:rgba(255,255,255,.07);font:600 23px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;-webkit-tap-highlight-color:transparent;touch-action:manipulation}
    .le-zoom-button:focus-visible,.le-quality-button:focus-visible{outline:2px solid #8de1ff;outline-offset:3px}
    #le-location-scanner{position:fixed;z-index:12;right:max(16px,env(safe-area-inset-right));top:calc(env(safe-area-inset-top) + 16px);display:flex;align-items:center;gap:8px;padding:10px 13px;border-radius:999px;border:1px solid rgba(255,70,100,.42);color:#ffeaf0;background:linear-gradient(145deg,rgba(90,12,32,.72),rgba(5,8,18,.84));box-shadow:inset 1px 1px 2px #ffffff24,0 5px 18px #0008;backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);font:650 11px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;letter-spacing:.12em;text-transform:uppercase;touch-action:manipulation;-webkit-tap-highlight-color:transparent}
    #le-location-scanner[aria-pressed="true"]{border-color:rgba(255,105,130,.95);box-shadow:inset 1px 1px 2px #ffffff30,0 0 14px rgba(255,35,75,.38),0 5px 18px #0008;color:#fff}
    #le-location-scanner .le-radar-dot{width:7px;height:7px;border-radius:50%;background:#ff234d;box-shadow:0 0 8px #ff234d}
    @media(max-height:560px){#le-quality-controls{bottom:calc(env(safe-area-inset-bottom) + 100px)}.le-quality-button{min-width:68px;padding:8px 10px}.le-zoom-button{width:34px;height:34px}}
    @media(prefers-reduced-motion:reduce){#le-quality-controls,.le-quality-button{transition:none!important}}
  `;
  document.head.appendChild(style);

  const controls = document.createElement("div");
  controls.id = "le-quality-controls";
  controls.hidden = true;
  controls.setAttribute("role", "group");
  controls.setAttribute("aria-label", "Independent Earth View controls");
  controls.innerHTML = `
    <button type="button" class="le-zoom-button" data-zoom="out" aria-label="Zoom out" title="Zoom out">−</button>
    <button type="button" class="le-quality-button" data-quality="basic" aria-pressed="true">Basic</button>
    <button type="button" class="le-quality-button" data-quality="hd" aria-pressed="false">HD</button>
    <button type="button" class="le-zoom-button" data-zoom="in" aria-label="Zoom in" title="Zoom in">+</button>`;
  document.body.appendChild(controls);

  const scannerButton = document.createElement("button");
  scannerButton.type = "button";
  scannerButton.id = "le-location-scanner";
  scannerButton.hidden = true;
  scannerButton.setAttribute("aria-pressed", "false");
  scannerButton.setAttribute("aria-label", "Show or hide the approved Location marker in Earth View");
  scannerButton.innerHTML = '<span class="le-radar-dot" aria-hidden="true"></span><span>Scanner</span>';
  document.body.appendChild(scannerButton);

  let stage = null, canvas = null, T = null, renderer = null, scene = null, camera = null;
  // 03 — Runtime state, owned resources and persisted view preferences.
  let earthGroup = null, earthMesh = null, atmosphere = null, locationMarker = null, earthGlobe = null;
  let earthInteractions = null, quality = "basic", active = false, activationGeneration = 0;
  let terrainController = null, terrainLoadPromise = null;
  let initialized = false, initPromise = null, drawFrame = 0, animationFrame = 0, solarTimer = 0;
  let resizeObserver = null, baseDistance = 0, scannerVisible = false, entering = false;
  let lastWidth = 0, lastHeight = 0, lastPixelRatio = 0;
  const fovRadians = FOV * Math.PI / 180;
  let solarVector = null, shaderUniforms = null, resizeSettleTimers = [];

  try { quality = localStorage.getItem(QUALITY_KEY) === "hd" ? "hd" : "basic"; } catch (_) {}

  function showStatus(message, duration = 2600) {
  // 04 — Small shared UI and status helpers.
    const status = document.querySelector("#status");
    if (!status) return;
    status.hidden = false;
    status.textContent = message;
    if (duration > 0) window.setTimeout(() => {
      if (status.textContent === message) status.hidden = true;
    }, duration);
  }

  function paintQuality() {
    controls.querySelectorAll("[data-quality]").forEach(button => {
      button.setAttribute("aria-pressed", String(button.dataset.quality === quality));
    });
  }

  function makeStage() {
  // 05 — Stage, viewport measurements and responsive geometry.
    if (stage?.isConnected) return;
    const root = document.getElementById("le-sky-view");
    if (!root) throw new Error("The shared Sky View stage is not ready.");
    stage = document.createElement("div");
    stage.id = STAGE_ID;
    stage.className = "le-ev-stage";
    stage.hidden = true;
    canvas = document.createElement("canvas");
    canvas.className = "le-ev-canvas";
    canvas.setAttribute("aria-label", "Interactive independent 3D Earth");
    canvas.setAttribute("role", "img");
    stage.appendChild(canvas);
    root.appendChild(stage);
    if (resizeObserver) {
      resizeObserver.observe(stage);
      stage.dataset.resizeObserved = "true";
    }
  }

  function viewport() {
    const rect = stage?.getBoundingClientRect?.() || { width: 0, height: 0 };
    const visual = window.visualViewport;
    return {
      width: Math.max(1, Math.round(rect.width || visual?.width || window.innerWidth || 1)),
      height: Math.max(1, Math.round(rect.height || visual?.height || window.innerHeight || 1))
    };
  }

  function distanceForDiameter(diameterFraction) {
  // 06 — Camera framing, transitions, quality and zoom controls.
    const size = viewport();
    const shortest = Math.max(1, Math.min(size.width, size.height));
    return size.height / (diameterFraction * shortest * Math.tan(fovRadians / 2));
  }
  function homeEquivalentDistance() { return distanceForDiameter(0.75); }
  function cinematicDistance() { return distanceForDiameter(TARGET_DIAMETER); }

  function queueDraw(skipTerrainUpdate = false) {
    if (!skipTerrainUpdate && quality === "hd") terrainController?.scheduleUpdate();
    if (!active || !renderer || !scene || !camera || drawFrame) return;
    drawFrame = requestAnimationFrame(() => {
      drawFrame = 0;
      if (active && renderer && scene && camera) renderer.render(scene, camera);
    });
  }
  function stopCameraAnimation() {
    if (animationFrame) cancelAnimationFrame(animationFrame);
    animationFrame = 0;
  }
  function animateCamera(target, duration = 860, onComplete = null) {
    stopCameraAnimation();
    if (!camera) return;
    const startDistance = camera.position.z, startedAt = performance.now();
    const length = reducedMotion() ? 0 : duration;
    const tick = now => {
      if (!active || !camera) { animationFrame = 0; return; }
      const progress = length ? clamp((now - startedAt) / length, 0, 1) : 1;
      const eased = 1 - Math.pow(1 - progress, 3);
      camera.position.z = startDistance + (target - startDistance) * eased;
      camera.lookAt(0, 0, 0);
      queueDraw();
      if (progress < 1) animationFrame = requestAnimationFrame(tick);
      else { animationFrame = 0; onComplete?.(); }
    };
    if (!length) {
      camera.position.z = target;
      camera.lookAt(0, 0, 0);
      queueDraw();
      onComplete?.();
      return;
    }
    animationFrame = requestAnimationFrame(tick);
  }

  async function loadTerrain() {
    if (navigator.onLine === false) throw new Error("HD terrain requires an internet connection.");
    if (terrainController) return terrainController.enable();
    if (!terrainLoadPromise) {
      terrainLoadPromise = import("./terrain-controller.js").then(module => {
        if (!active || quality !== "hd" || navigator.onLine === false) return false;
        terrainController = module.createEarthTerrainController({
          THREE: T,
          earthMesh,
          requestRender: () => queueDraw(true),
          getCameraDistance: () => camera?.position.z,
          getHomeDistance: homeEquivalentDistance,
          onStatus: message => showStatus(message, 3600),
          onUnavailable: () => {
            if (quality !== "hd") return;
            setQuality("basic");
            showStatus("HD terrain could not be reached. Check your connection and try HD again.", 5200);
          }
        });
        return terrainController.enable();
      }).finally(() => { terrainLoadPromise = null; });
    }
    return terrainLoadPromise;
  }

  function setQuality(next) {
    let requested = next === "hd" ? "hd" : "basic";
    if (requested === "hd" && navigator.onLine === false) {
      requested = "basic";
      showStatus("HD terrain needs an internet connection. Basic Earth remains available.", 4200);
    }
    quality = requested;
    try { localStorage.setItem(QUALITY_KEY, quality); } catch (_) {}
    if (renderer && earthMesh && earthGlobe) {
      earthGlobe.setGeometryDetail(quality === "hd" ? "high" : "standard");
      const pixelRatio = Math.min(window.devicePixelRatio || 1, quality === "hd" ? 1.5 : 1);
      renderer.setPixelRatio(pixelRatio);
      lastPixelRatio = pixelRatio;
      resizeRenderer(false);
    }
    if (quality === "hd" && initialized && active) {
      loadTerrain().catch(error => {
        console.warn("[LIVE // EARTH] HD terrain could not start.", error);
        if (quality === "hd") setQuality("basic");
        showStatus("HD terrain could not start. Basic Earth remains available.", 5200);
      });
    } else if (quality !== "hd") {
      terrainController?.disable();
    }
    paintQuality();
    queueDraw();
    return quality;
  }

  function zoomLimits() {
    return {
      minimum: quality === "hd" ? 1.2 : cinematicDistance() * 0.86,
      maximum: baseDistance || homeEquivalentDistance()
    };
  }
  function setCameraDistance(distance) {
    if (!camera || !Number.isFinite(distance)) return;
    const limits = zoomLimits();
    camera.position.z = clamp(distance, limits.minimum, limits.maximum);
    camera.lookAt(0, 0, 0);
    queueDraw();
  }
  function zoomBy(factor) {
    if (!active || !camera || !Number.isFinite(factor) || factor <= 0) return;
    entering = false;
    const limits = zoomLimits();
    const target = clamp(camera.position.z * factor, limits.minimum, limits.maximum);
    animateCamera(target, 360);
  }

  function syncLocationMarker() {
  // 07 — Approved location integration and solar direction.
    if (!locationMarker) return;
    const allowed = window.liveEarthLocationAllowed?.() === true;
    const api = window.LiveEarthPrimeScene;
    const position = allowed ? api?.getLocation?.() : null;
    if (!position || !Number.isFinite(position.latitude) || !Number.isFinite(position.longitude)) {
      locationMarker.visible = false;
      queueDraw();
      return;
    }
    const latitude = position.latitude * Math.PI / 180;
    const longitude = position.longitude * Math.PI / 180;
    const vector = new T.Vector3(
      Math.cos(latitude) * Math.cos(longitude), Math.sin(latitude),
      -Math.cos(latitude) * Math.sin(longitude)
    ).normalize();
    locationMarker.children[0].position.copy(vector).multiplyScalar(1.006);
    locationMarker.children[1].position.copy(vector).multiplyScalar(1.019);
    locationMarker.visible = scannerVisible;
    queueDraw();
  }

  function updateSolarDirection(date = new Date()) {
    if (!earthMesh || !solarVector || !T) return;
    const start = Date.UTC(date.getUTCFullYear(), 0, 0);
    const day = Math.floor((Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()) - start) / 86400000);
    const hour = date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600;
    const gamma = 2 * Math.PI / 365 * (day - 1 + (hour - 12) / 24);
    const declination = 0.006918 - 0.399912 * Math.cos(gamma) + 0.070257 * Math.sin(gamma)
      - 0.006758 * Math.cos(2 * gamma) + 0.000907 * Math.sin(2 * gamma)
      - 0.002697 * Math.cos(3 * gamma) + 0.00148 * Math.sin(3 * gamma);
    const equationMinutes = 229.18 * (0.000075 + 0.001868 * Math.cos(gamma) - 0.032077 * Math.sin(gamma)
      - 0.014615 * Math.cos(2 * gamma) - 0.040849 * Math.sin(2 * gamma));
    const subsolarLongitude = (720 - (hour * 60 + equationMinutes)) * Math.PI / 720;
    const local = new T.Vector3(
      Math.cos(declination) * Math.cos(subsolarLongitude), Math.sin(declination),
      -Math.cos(declination) * Math.sin(subsolarLongitude)
    ).normalize();
    const worldQuaternion = new T.Quaternion();
    earthMesh.getWorldQuaternion(worldQuaternion);
    solarVector.copy(local).applyQuaternion(worldQuaternion).normalize();
    const light = scene.children.find(object => object.isDirectionalLight && object.userData.leSolarKey);
    if (light) {
      light.position.copy(solarVector).multiplyScalar(12);
      light.target.position.set(0, 0, 0);
      light.target.updateMatrixWorld();
    }
    if (shaderUniforms?.uLESunDirection) shaderUniforms.uLESunDirection.value.copy(solarVector).negate();
    queueDraw();
  }

  function installDayNightShader(material) {
    material.onBeforeCompile = shader => {
      shader.uniforms.uLESunDirection = { value: solarVector.clone().negate() };
      shader.vertexShader = shader.vertexShader
        .replace("void main() {", "varying vec3 vLEWorldNormal;\nvoid main() {")
        .replace("#include <beginnormal_vertex>", "#include <beginnormal_vertex>\n vLEWorldNormal = normalize(mat3(modelMatrix) * objectNormal);");
      shader.fragmentShader = shader.fragmentShader
        .replace("void main() {", "uniform vec3 uLESunDirection;\nvarying vec3 vLEWorldNormal;\nvoid main() {")
        .replace("#include <emissivemap_fragment>", `#include <emissivemap_fragment>
          float leSolarDot = dot(normalize(vLEWorldNormal), normalize(uLESunDirection));
          float leNight = 1.0 - smoothstep(-0.10, 0.08, leSolarDot);
          float leTwilight = 1.0 - smoothstep(0.015, 0.24, abs(leSolarDot));
          totalEmissiveRadiance += diffuseColor.rgb * leNight * 0.14;
          totalEmissiveRadiance += vec3(0.012, 0.026, 0.052) * leTwilight * 0.20;`);
      shaderUniforms = shader.uniforms;
    };
    material.customProgramCacheKey = () => "live-earth-independent-day-night-v1";
    material.needsUpdate = true;
  }

  function addStars() {
  // 08 — Globe-owned visual elements: environment, marker and day/night skin.
    const positions = [];
    let seed = 721;
    const random = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
    for (let i = 0; i < 500; i++) {
      const radius = 18 + random() * 25, angle = random() * Math.PI * 2, z = random() * 2 - 1;
      const ring = Math.sqrt(1 - z * z);
      positions.push(radius * ring * Math.cos(angle), radius * z, radius * ring * Math.sin(angle));
    }
    const geometry = new T.BufferGeometry();
    geometry.setAttribute("position", new T.Float32BufferAttribute(positions, 3));
    scene.add(new T.Points(geometry, new T.PointsMaterial({ color: 0xa9c9ec, size: 0.045, transparent: true, opacity: 0.72 })));
  }

  function addLocationMarker() {
    locationMarker = new T.Group();
    const halo = new T.Mesh(new T.SphereGeometry(0.031, 16, 12),
      new T.MeshBasicMaterial({ color: 0xff234d, transparent: true, opacity: 0.28, depthWrite: false }));
    const dot = new T.Mesh(new T.SphereGeometry(0.014, 16, 12),
      new T.MeshBasicMaterial({ color: 0xff183f, depthWrite: false }));
    locationMarker.add(halo, dot);
    locationMarker.visible = false;
    earthMesh.add(locationMarker);
  }

  // Earth View's own controller mirrors Atmosphere's geographic surface anchor.
  // 09 — Surface-anchored interaction: pointer admission, drag, pinch and cleanup.
  // The Engine capture-phase gesture controller is deliberately not attached.
  function attachSurfaceAnchoredInteractions() {
    const raycaster = new T.Raycaster();
    const pointerNdc = new T.Vector2();
    const anchorLocal = new T.Vector3();
    const anchorWorld = new T.Vector3();
    const targetWorld = new T.Vector3();
    const sphere = new T.Sphere(new T.Vector3(0, 0, 0), 1.001);
    const deltaRotation = new T.Quaternion();
    const worldXAxis = new T.Vector3(1, 0, 0);
    const localYAxis = new T.Vector3(0, 1, 0);
    const tiltRotation = new T.Quaternion();
    const headingRotation = new T.Quaternion();
    const pointers = new Map();
    const MIN_TILT = -1.15, MAX_TILT = 1.15;
    let activePointerId = null, pinchStartDistance = 0, pinchStartCameraDistance = 0;
    let hasAnchor = false, disposed = false;

    const isEnabled = () => !disposed && active && !!canvas?.isConnected;
    function updatePointerRay(x, y) {
      const rect = canvas.getBoundingClientRect();
      if (!(rect.width > 0 && rect.height > 0)) return false;
      pointerNdc.set(((x - rect.left) / rect.width) * 2 - 1,
        -((y - rect.top) / rect.height) * 2 + 1);
      raycaster.setFromCamera(pointerNdc, camera);
      return true;
    }
    function pickSurfacePoint(x, y, target) {
      if (!updatePointerRay(x, y)) return false;
      const hits = raycaster.intersectObject(earthMesh, true);
      if (!hits.length) return false;
      earthGroup.updateMatrixWorld(true);
      target.copy(hits[0].point);
      earthGroup.worldToLocal(target);
      return target.lengthSq() > 0;
    }
    function pointerRayToSphere(x, y, target) {
      if (!updatePointerRay(x, y)) return false;
      if (!raycaster.ray.intersectSphere(sphere, target)) return false;
      target.normalize();
      return true;
    }
    function clampGlobeTilt() {
      const q = earthGroup.quaternion;
      const headingHalf = Math.atan2(q.y, q.w);
      const sinHalfTilt = q.x * Math.cos(headingHalf) + q.z * Math.sin(headingHalf);
      const cosHalfTilt = Math.hypot(q.w, q.y);
      const tilt = 2 * Math.atan2(sinHalfTilt, cosHalfTilt);
      const boundedTilt = clamp(tilt, MIN_TILT, MAX_TILT);
      const heading = 2 * headingHalf;
      tiltRotation.setFromAxisAngle(worldXAxis, boundedTilt);
      headingRotation.setFromAxisAngle(localYAxis, heading);
      q.copy(tiltRotation).multiply(headingRotation).normalize();
    }
    function pointerDistance() {
      const values = [...pointers.values()];
      return values.length < 2 ? 0 : Math.hypot(values[0].x - values[1].x, values[0].y - values[1].y);
    }
    function beginAnchor(pointer) {
      hasAnchor = pickSurfacePoint(pointer.x, pointer.y, anchorLocal);
      activePointerId = hasAnchor ? pointer.id : null;
      return hasAnchor;
    }
    function onPointerDown(event) {
      if (!isEnabled() || (event.pointerType === "mouse" && event.button !== 0)) return;
      if (pointers.has(event.pointerId)) return;
      const pointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
      // Only admit a pointer that begins on the visible globe surface.
      if (!pickSurfacePoint(pointer.x, pointer.y, anchorLocal)) return;
      pointers.set(event.pointerId, pointer);
      try { canvas.setPointerCapture(event.pointerId); } catch (_) {}
      if (pointers.size === 1) {
        beginAnchor(pointer);
      } else if (pointers.size === 2) {
        hasAnchor = false;
        activePointerId = null;
        pinchStartDistance = Math.max(1, pointerDistance());
        pinchStartCameraDistance = camera.position.z;
      } else {
        pointers.delete(event.pointerId);
        try { if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId); } catch (_) {}
        return;
      }
      entering = false;
      stopCameraAnimation();
      event.preventDefault();
    }
    function onPointerMove(event) {
      if (!isEnabled() || !pointers.has(event.pointerId)) return;
      const pointer = pointers.get(event.pointerId);
      pointer.x = event.clientX;
      pointer.y = event.clientY;
      if (pointers.size >= 2) {
        const distance = pointerDistance();
        if (pinchStartDistance > 0 && distance > 0) {
          setCameraDistance(pinchStartCameraDistance * pinchStartDistance / distance);
        }
        event.preventDefault();
        return;
      }
      if (pointers.size !== 1 || event.pointerId !== activePointerId || !hasAnchor) return;
      if (!pointerRayToSphere(pointer.x, pointer.y, targetWorld)) return;
      earthGroup.updateMatrixWorld(true);
      anchorWorld.copy(anchorLocal).applyQuaternion(earthGroup.quaternion).normalize();
      deltaRotation.setFromUnitVectors(anchorWorld, targetWorld);
      earthGroup.quaternion.premultiply(deltaRotation).normalize();
      clampGlobeTilt();
      earthGroup.updateMatrixWorld(true);
      updateSolarDirection();
      queueDraw();
      event.preventDefault();
    }
    function finishPointer(event) {
      if (!pointers.has(event.pointerId)) return;
      pointers.delete(event.pointerId);
      try {
        if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
      } catch (_) {}
      if (pointers.size === 1) {
        const remaining = [...pointers.values()][0];
        // Re-anchor the remaining finger after a pinch without a rotation jump.
        beginAnchor(remaining);
      } else if (pointers.size >= 2) {
        hasAnchor = false;
        activePointerId = null;
        pinchStartDistance = Math.max(1, pointerDistance());
        pinchStartCameraDistance = camera.position.z;
      } else {
        hasAnchor = false;
        activePointerId = null;
        pinchStartDistance = 0;
      }
      if (event.cancelable) event.preventDefault();
    }
    function reset() {
      const capturedPointers = [...pointers.keys()];
      pointers.clear();
      hasAnchor = false;
      activePointerId = null;
      pinchStartDistance = 0;
      for (const pointerId of capturedPointers) {
        try { if (canvas.hasPointerCapture(pointerId)) canvas.releasePointerCapture(pointerId); } catch (_) {}
      }
    }
    function dispose() {
      if (disposed) return;
      reset();
      disposed = true;
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", finishPointer);
      canvas.removeEventListener("pointercancel", finishPointer);
      canvas.removeEventListener("lostpointercapture", finishPointer);
    }
    canvas.addEventListener("pointerdown", onPointerDown, { passive: false });
    canvas.addEventListener("pointermove", onPointerMove, { passive: false });
    canvas.addEventListener("pointerup", finishPointer);
    canvas.addEventListener("pointercancel", finishPointer);
    canvas.addEventListener("lostpointercapture", finishPointer);
    return Object.freeze({ reset, dispose });
  }

  async function initializeRenderer() {
  // 10 — Earth Engine instance and base globe construction.
    if (initialized) return true;
    if (initPromise) return initPromise;
    makeStage();
    initPromise = (async () => {
      T = await import("../vendor/three.module.js");
      renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "low-power" });
      renderer.outputColorSpace = T.SRGBColorSpace;
      renderer.setClearColor(0x02050b, 1);
      scene = new T.Scene();
      scene.background = new T.Color(0x02050b);
      const size = viewport();
      camera = new T.PerspectiveCamera(FOV, size.width / size.height, 0.1, 180);
      camera.position.set(0, 0, homeEquivalentDistance());
      camera.lookAt(0, 0, 0);
      scene.add(new T.AmbientLight(0x8aa7c8, 0.12));
      const sunlight = new T.DirectionalLight(0xffffff, 2.3);
      sunlight.userData.leSolarKey = true;
      sunlight.position.set(-3, 2, 4);
      scene.add(sunlight);
      const fill = new T.DirectionalLight(0x245b9b, 0.055);
      fill.position.set(4, -2, -3);
      scene.add(fill);

      const engineModule = await import("../EarthEngine/Core/earth-engine.js");
      const createEarthGlobe = engineModule.createEarthGlobe || engineModule.createGlobe || window.LiveEarthEngine?.createGlobe;
      if (typeof createEarthGlobe !== "function") throw new Error("The reusable Earth Engine API is unavailable.");
      earthGlobe = await createEarthGlobe({
        THREE: T, radius: 1,
        textureUrl: "./EarthEngine/Assets/earth-land-ocean-ice-2048.png",
        geometryDetail: quality === "hd" ? "high" : "standard",
        maxAnisotropy: renderer.capabilities.getMaxAnisotropy(),
        atmosphere: true
      });
      earthGroup = earthGlobe.group;
      earthMesh = earthGlobe.surface;
      atmosphere = earthGlobe.atmosphere;
      scene.add(earthGroup);
      earthInteractions = attachSurfaceAnchoredInteractions();

      solarVector = new T.Vector3(0, 0, 1);
      installDayNightShader(earthMesh.material);
      addLocationMarker();
      addStars();
      initialized = true;
      setQuality(quality);
      resizeRenderer(true);
      updateSolarDirection();
      queueDraw();
      return true;
    })().catch(error => {
      initPromise = null;
      console.error("[LIVE // EARTH] Independent Earth renderer could not initialize.", error);
      showStatus("Earth View could not load its local 3D resources. Prime Earth remains untouched.", 6000);
      throw error;
    });
    return initPromise;
  }

  function resizeRenderer(resetDistance = false) {
  // 11 — Renderer sizing, pixel ratio and orientation settling.
    if (!active || !renderer || !camera || !stage) return;
    const size = viewport();
    const previousBase = baseDistance || homeEquivalentDistance();
    const previousRatio = camera.position.z > 0 ? camera.position.z / previousBase : 1;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, quality === "hd" ? 1.5 : 1);
    if (size.width !== lastWidth || size.height !== lastHeight || pixelRatio !== lastPixelRatio) {
      renderer.setPixelRatio(pixelRatio);
      renderer.setSize(size.width, size.height, false);
      lastWidth = size.width;
      lastHeight = size.height;
      lastPixelRatio = pixelRatio;
    }
    camera.aspect = size.width / size.height;
    camera.fov = FOV;
    camera.updateProjectionMatrix();
    baseDistance = homeEquivalentDistance();
    if (resetDistance) camera.position.z = baseDistance;
    else {
      const minimum = quality === "hd" ? 1.2 : cinematicDistance() * 0.86;
      camera.position.z = clamp(baseDistance * previousRatio, minimum, baseDistance);
    }
    camera.lookAt(0, 0, 0);
    queueDraw();
  }

  function queueResize(settle = false) {
    if (!active) return;
    const continueEntry = entering;
    if (settle) {
      resizeSettleTimers.forEach(timer => clearTimeout(timer));
      resizeSettleTimers = [100, 300, 650].map(delay => window.setTimeout(() => {
        if (!active) return;
        stopCameraAnimation();
        resizeRenderer(false);
        if (continueEntry && entering) animateCamera(cinematicDistance(), 380, () => { entering = false; });
      }, delay));
    }
    requestAnimationFrame(() => {
      if (!active) return;
      stopCameraAnimation();
      resizeRenderer(false);
      if (continueEntry && entering) animateCamera(cinematicDistance(), 380, () => { entering = false; });
    });
  }

  function activate() {
  // 12 — View activation/deactivation and owned runtime lifecycle.
    active = true;
    const activation = ++activationGeneration;
    makeStage();
    stage.hidden = false;
    controls.hidden = false;
    scannerButton.hidden = false;
    paintQuality();
    initializeRenderer().then(() => {
      if (!active || activation !== activationGeneration) return;
      resizeRenderer(true);
      camera.position.z = baseDistance;
      camera.lookAt(0, 0, 0);
      syncLocationMarker();
      updateSolarDirection();
      queueDraw();
      if (quality === "hd" && navigator.onLine !== false) {
        loadTerrain().catch(error => console.warn("[LIVE // EARTH] HD terrain could not resume.", error));
      }
      entering = true;
      animateCamera(cinematicDistance(), 900, () => { entering = false; });
      if (!solarTimer) solarTimer = window.setInterval(() => {
        if (active && !document.hidden) updateSolarDirection(new Date());
      }, 30000);
    }).catch(() => {});
    window.dispatchEvent(new CustomEvent("live-earth-exclusive-mode", { detail: { active: true } }));
  }

  function deactivate() {
    active = false;
    activationGeneration++;
    entering = false;
    stopCameraAnimation();
    earthInteractions?.reset();
    terrainController?.disable();
    if (drawFrame) cancelAnimationFrame(drawFrame);
    drawFrame = 0;
    if (solarTimer) window.clearInterval(solarTimer);
    solarTimer = 0;
    resizeSettleTimers.forEach(timer => clearTimeout(timer));
    resizeSettleTimers = [];
    if (stage) stage.hidden = true;
    controls.hidden = true;
    scannerButton.hidden = true;
    scannerVisible = false;
    scannerButton.setAttribute("aria-pressed", "false");
    if (locationMarker) locationMarker.visible = false;
    window.dispatchEvent(new CustomEvent("live-earth-exclusive-mode", { detail: { active: false } }));
  }

  // 13 — UI actions and application event wiring.
  controls.querySelectorAll("[data-quality]").forEach(button => {
    button.addEventListener("click", () => setQuality(button.dataset.quality));
  });
  controls.querySelectorAll("[data-zoom]").forEach(button => {
    button.addEventListener("click", () => zoomBy(button.dataset.zoom === "in" ? 0.82 : 1.22));
  });
  scannerButton.addEventListener("click", () => {
    if (window.liveEarthLocationAllowed?.() !== true) {
      scannerVisible = false;
      scannerButton.setAttribute("aria-pressed", "false");
      syncLocationMarker();
      showStatus("Turn the Location Orb ON first. Earth View will not request your location.");
      return;
    }
    scannerVisible = !scannerVisible;
    scannerButton.setAttribute("aria-pressed", String(scannerVisible));
    syncLocationMarker();
    showStatus(scannerVisible ? "Location Scanner ON · showing the approved marker in Earth View." : "Location Scanner hidden · Location remains ON.");
  });

  window.addEventListener("live-earth-location-state", event => {
    if (event.detail?.enabled !== true) {
      scannerVisible = false;
      scannerButton.setAttribute("aria-pressed", "false");
    }
    if (active) syncLocationMarker();
  });
  window.addEventListener("live-earth-location-stop", () => {
    scannerVisible = false;
    scannerButton.setAttribute("aria-pressed", "false");
    if (active) syncLocationMarker();
  });
  window.addEventListener("offline", () => {
    if (quality === "hd") {
      setQuality("basic");
      showStatus("HD terrain paused because the connection was lost. Basic Earth remains available.", 5200);
    }
  });
  window.addEventListener("resize", () => queueResize(false), { passive: true });
  window.addEventListener("orientationchange", () => queueResize(true), { passive: true });
  window.addEventListener("pageshow", () => queueResize(true), { passive: true });
  window.visualViewport?.addEventListener("resize", () => queueResize(true), { passive: true });
  if (typeof ResizeObserver === "function") {
    resizeObserver = new ResizeObserver(() => queueResize(false));
  }

  function registerModule() {
  // 14 — Feature-module registration and startup handoff.
    if (!window.LiveEarthViewModules || window.LiveEarthViewModules.has("earth-independent-renderer")) return;
    window.LiveEarthViewModules.register("earth-independent-renderer", {
      views: ["earth"], activate, deactivate
    });
    window.__liveEarthEarthRendererInstalled = true;
    window.dispatchEvent(new Event("live-earth-startup-ready"));
  }
  function registerAfterSkyHost() {
    if (window.LiveEarthSkyViews && document.getElementById("le-sky-view")) {
      registerModule();
      return;
    }
    window.addEventListener("live-earth-sky-view-ready", registerModule, { once: true });
  }
  if (window.LiveEarthViewModules) registerAfterSkyHost();
  else window.addEventListener("live-earth-view-modules-ready", registerAfterSkyHost, { once: true });

  document.addEventListener("keydown", event => {
    if (event.key !== "Escape" || !window.LiveEarthViewManager?.isActive("earth")) return;
    window.LiveEarthViewManager.requestView("home");
  });
})();
