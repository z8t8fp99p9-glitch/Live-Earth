"""LIVE // EARTH data package."""
