# Atmosphere globe-first rendering patch

Scope: one change in `Atmosphere/atmosphere-view-controller.js`.

- The base Earth is rendered immediately after it is added to the scene.
- Country borders load asynchronously and attach when ready.
- If Atmosphere closes before borders finish loading, the late result is disposed.
- No caching, memory retention, NOAA data pipeline, checksums, grid resolution, palette, controls, or other views are changed.

Apply from the repository root:

```bash
git apply --check atmosphere-globe-first.patch
git apply atmosphere-globe-first.patch
```

Then open Atmosphere and confirm the base globe appears before the country boundaries finish loading.
