LIVE // EARTH — Live Cams Home-stage cleanup fix
Prepared: 14 November 2026
Repository: z8t8fp99p9-glitch/Live-Earth
Branch: main

ROOT CAUSE
The current Traffic/traffic-view.js registers Live Cams directly with
window.LiveEarthFeatureViews. Its deactivate callback was empty. Activation
calls LiveEarthStacksFeatureRuntime.mount('live-cams'), which adds the
.le-sfv-open class to #le-feature-stage. The Stacks stylesheet uses that class
to force display:block!important. The Global Orb close path sets stage.hidden
but does not itself remove le-sfv-open. The stale stage can therefore remain
visible over Home.

PATCH CONTENTS
- Traffic/traffic-view.js — retain an idempotent cleanup closure for each
  wallpaper mount; Live Cams invokes it when its Orb closes. It removes the
  mounted feature root, removes le-sfv-open only when no newer feature root is
  present, and restores the stage card. Traffic uses the same closure through
  the normal Stacks runtime cleanup wrapper.
- Tests/live-cameras-workspace.test.cjs — replace stale assertions for an older
  independent-globe implementation with source-contract and lifecycle tests
  for the current empty wallpaper view.

PROTECTED
No edits to index.html, Home Earth, Earth Engine, Earth View, Moon, Sun,
Global Orb navigation, Location privacy, databases, or user data. No second
renderer or WebGL context is introduced. No GitHub commit or deployment was
performed.

APPLY
Extract the ZIP at the repository root, preserving the included folder paths.
Run: node Tests/live-cameras-workspace.test.cjs
Then launch the app online once and allow its existing startup gate to finish
its fresh essential-file sync. The service worker already refreshes the
Traffic/traffic-view.js app-shell entry during that online sync; this primes
the corrected file for subsequent offline launches. Then test opening and
closing Live Cams and returning to Home, including switching to Earth View.

Suggested GitHub commit title:
Fix Live Cams stage cleanup on close

VERIFICATION BOUNDARY
The included regression test is run against this patch in isolation. Full
repository CI and actual iPhone runtime verification must be completed after
the patch is extracted and deployed.
