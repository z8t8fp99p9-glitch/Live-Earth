# LIVE // EARTH — Global Editorial Text Intelligence Upgrade

## Scope

This is a text-editing upgrade inside the existing Global Editorial Engine only.
It does not change the Newsroom pipeline, Checker handoff, Manager, Collector,
Image Engine, database writer, per-View databases, Publishers, workflows, or
browser views. Image processing is unchanged.

## Files in this package

- `editorial-engine/editorial_text_intelligence.py` — new local-only text
  ranking, redundancy reduction, and extractive summary module.
- `editorial-engine/universal_editorial_engine_newsroom.py` — existing global
  Newsroom adapter, updated to call the new text module while retaining its
  existing public function and handoff contracts.
- `editorial-engine/tests/test_editorial_text_intelligence.py` — focused tests
  for ranking, redundancy, fact markers, sentence order, and deterministic output.
- `editorial-engine/tests/test_universal_editorial_engine_newsroom.py` —
  adapter regression tests for Checker handoff, source preservation, image
  linkage, Manager lineage, and the upgraded text behaviour.

## What changed in text handling

1. Uses TF-IDF sentence vectors and weighted TextRank-style graph ranking.
2. Combines graph centrality with title relevance, a modest lead preference,
   factual-marker density, and a small quotation-preservation preference.
3. Uses Maximal Marginal Relevance (MMR) to reduce repeated information.
4. For source text up to 500 words, preserves distinct text but removes exact
   and very-close duplicate sentences when their numeric markers and quotations
   are identical.
5. For longer source text, selects complete source sentences, then restores
   their original order. It never generates new sentences or paraphrases.
6. Preserves changes in numeric/measurement values and quoted wording; negation
   words such as “not” remain meaningful tokens.
7. If the remaining distinct information is under 200 words, returns it as-is
   and marks `SOURCE_UNDER_200_WORDS` rather than repeating content or padding.
8. The complete original Checker-cleared source record remains unchanged and
   continues to be retained separately by the adapter.

## Local-only guarantees

- Standard-library Python only for the new text module.
- No network requests or external data fetching.
- No third-party NLP package.
- No hosted model, AI API, API key, paid service, or downloaded language model.
- No new dependency entry in `requirements.txt`.

## Test

From the repository root, run:

```bash
python -m unittest discover -s editorial-engine/tests -v
```

The tests included in this package were run locally: 29 tests passed.

## Compatibility notes

- `build_editorial_summary(source_summary, source_title="")` keeps the same
  function signature and output keys.
- The existing `produce_editorial_package(...)` interface and Checker handoff
  fields are unchanged.
- The existing `summaryStatus` values remain `WITHIN_TARGET`,
  `SOURCE_UNDER_200_WORDS`, and `EXTRACTED_BOUNDARY_FALLBACK` where applicable.
- `summaryMethod` identifies the new local algorithms:
  `textrank-mmr-extractive-v2` and `near-duplicate-reduction-v2`.
- Editorial remains extractive in this phase. Headline rewriting, paragraph
  rewriting, and image editing are deliberately not included yet.

## Deployment boundary

Copy the package paths into the repository preserving their directory
structure. Do not run a database reset, alter cache keys, change workflows,
modify the Checker contract, or change any View Publisher configuration.
