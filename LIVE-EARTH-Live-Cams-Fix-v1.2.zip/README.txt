LIVE // EARTH — Live Cams integration repair v1.2

IMPORTANT
- This is a source patch for the current LIVE // EARTH repository main branch.
- It does not write to GitHub.
- Traffic is restored to the original Traffic-only implementation.
- Live Cams is a separate Stacks feature and adds no Home/primary Orb.
- The Live Cams overlay is transparent and attaches markers to the existing shared Earth layer.

FILES
1. Traffic/traffic-view.js — restore original Traffic-only module.
2. LiveCams/live-cams-view.js — new dedicated Live Cams module.
3. PATCH/stacks-feature-views.patch — apply to Stacks/stacks-feature-views.js.
4. PATCH/sw.patch — apply to sw.js so the new module is loaded and cached.

APPLY
Apply both unified patches from the repository root (or make the same three small edits manually).
Then upload/extract the package through your normal workflow.

STACKS edits required by the patch:
- Add live-cams metadata and pill label.
- Load ./LiveCams/live-cams-view.js as an additional external module.
- Existing feature order is preserved; Live Cams is appended after Traffic.

VALIDATION LIMITS
The package includes source-level validation only. A real device/deployment check is still required to confirm the shared Earth renderer is visible beneath the transparent feature overlay and the camera provider is reachable.
