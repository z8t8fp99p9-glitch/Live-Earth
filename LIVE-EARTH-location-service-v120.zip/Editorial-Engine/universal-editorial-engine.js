/* LIVE // EARTH — GLOBAL Universal Editorial Engine client contract.
   The publishing implementation is universal_editorial_engine.py in this folder.
   This browser layer validates published view outputs; it does not fetch sources
   or write databases. Nature has a separate, strict published-image URL boundary. */
(() => {
  'use strict';
  if (window.__liveEarthUniversalEditorialEngineInstalled) return;

  const VERSION = '1.0.1';
  const ENGINE = 'Universal Editorial Engine';
  const MAX_FEED_STORIES = 100;
  const NATURE_RAW_PREFIX = '/z8t8fp99p9-glitch/Live-Earth/main/nature/published/';

  function safeText(value, limit = 3000) {
    return typeof value === 'string' ? value.replace(/\s+/g, ' ').trim().slice(0, limit) : '';
  }
  function safeHttps(value) {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && !u.username && !u.password;
    } catch (_) { return false; }
  }
  function safeNasaImage(value) {
    try {
      const u = new URL(value);
      const host = u.hostname.toLowerCase().replace(/\.$/, '');
      const nasaOwnedHost = host === 'nasa.gov' || host.endsWith('.nasa.gov');
      return u.protocol === 'https:' && nasaOwnedHost && !u.username && !u.password;
    } catch (_) { return false; }
  }
  function safeNaturePublicationImage(value) {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && u.hostname.toLowerCase() === 'raw.githubusercontent.com' &&
        u.pathname.startsWith(NATURE_RAW_PREFIX + 'assets/') &&
        !u.username && !u.password;
    } catch (_) { return false; }
  }
  function safeNaturePdf(value) {
    try {
      const u = new URL(value);
      return u.protocol === 'https:' && u.hostname.toLowerCase() === 'raw.githubusercontent.com' &&
        u.pathname === NATURE_RAW_PREFIX + 'current.pdf' &&
        !u.username && !u.password;
    } catch (_) { return false; }
  }
  function validateFeed(payload, expectedViewId) {
    if (!payload || payload.schemaVersion !== 1 || payload.viewId !== expectedViewId || !Array.isArray(payload.stories)) {
      throw new Error('The published feed does not match the requested view contract.');
    }
    const stories = [];
    const seen = new Set();
    for (const item of payload.stories.slice(0, MAX_FEED_STORIES)) {
      const id = safeText(item && item.id, 100);
      const title = safeText(item && item.title, 240);
      const url = safeText(item && item.url, 1000);
      if (!id || !title || !safeHttps(url) || seen.has(url)) continue;
      seen.add(url);
      const imageUrl = expectedViewId === 'nature'
        ? (safeNaturePublicationImage(item.imageUrl) ? item.imageUrl : '')
        : (safeNasaImage(item.imageUrl) ? item.imageUrl : '');
      stories.push({
        id, title, url,
        summary: safeText(item.summary, 1900),
        sourceName: safeText(item.sourceName, 120),
        sourceUrl: safeHttps(item.sourceUrl) ? item.sourceUrl : '',
        publishedAt: safeText(item.publishedAt, 80),
        imageUrl,
        imageCredit: safeText(item.imageCredit, 500),
        imageCaption: expectedViewId === 'nature' ? safeText(item.imageCaption, 500) : '',
        imageLicense: expectedViewId === 'nature' ? safeText(item.imageLicense, 100) : '',
        imageLicenseUrl: expectedViewId === 'nature' && safeHttps(item.imageLicenseUrl) ? item.imageLicenseUrl : '',
        imageSourceUrl: safeHttps(item.imageSourceUrl) ? item.imageSourceUrl : '',
        imageRightsNote: safeText(item.imageRightsNote, 700)
      });
    }
    return Object.freeze({
      schemaVersion: 1,
      viewId: expectedViewId,
      generatedAt: safeText(payload.generatedAt, 80),
      windowHours: Number.isFinite(payload.windowHours) ? payload.windowHours : 48,
      storyCount: stories.length,
      documentaryImageCount: Number(payload.documentaryImageCount) || stories.filter(s => s.imageUrl).length,
      stories: Object.freeze(stories)
    });
  }
  function normalizedHttpsUrl(value) {
    try {
      const url = new URL(value, document.baseURI);
      return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
    } catch (_) { return ''; }
  }
  function validateReceipt(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const cleanList = key => Array.isArray(value[key])
      ? value[key].slice(0, 12).map(item => safeText(item, 240)).filter(Boolean)
      : [];
    return Object.freeze({
      applied: Object.freeze(cleanList('applied')),
      unmapped: Object.freeze(cleanList('unmapped')),
      palette: safeText(value.palette, 80),
      photoLed: typeof value.photoLed === 'boolean' ? value.photoLed : null,
      includeTimeline: typeof value.includeTimeline === 'boolean' ? value.includeTimeline : null,
      includeExplainer: typeof value.includeExplainer === 'boolean' ? value.includeExplainer : null,
      requestedPageCount: Number(value.requestedPageCount) || 0,
      actualPageCount: Number(value.actualPageCount) || 0,
      note: safeText(value.note, 500),
      engineLimitation: safeText(value.engineLimitation, 500)
    });
  }
  function validateCatalog(payload, expectedViewId) {
    if (!payload || payload.schemaVersion !== 1 || payload.viewId !== expectedViewId || !Array.isArray(payload.issues)) {
      throw new Error('The magazine catalog does not match the requested view contract.');
    }
    const issues = [];
    const sourceIssues = expectedViewId === 'nature' ? payload.issues.slice(0, 1) : payload.issues.slice(0, 8);
    for (const issue of sourceIssues) {
      if (!issue) continue;
      const issueId = safeText(issue.issueId, 100);
      const pdfUrl = expectedViewId === 'nature'
        ? (safeNaturePdf(issue.pdfUrl) ? issue.pdfUrl : '')
        : normalizedHttpsUrl(issue.pdfUrl);
      const sha256 = /^[a-f0-9]{64}$/i.test(String(issue.sha256 || '')) ? String(issue.sha256).toLowerCase() : '';
      if (!issueId || !pdfUrl || !sha256) continue;
      const coverImageUrl = expectedViewId === 'nature' && safeNaturePublicationImage(issue.coverImageUrl)
        ? issue.coverImageUrl : '';
      issues.push({
        issueId,
        title: safeText(issue.title, 180),
        publishedAt: safeText(issue.publishedAt, 80),
        coverageStart: safeText(issue.coverageStart, 80),
        coverageEnd: safeText(issue.coverageEnd, 80),
        windowHours: Number(issue.windowHours) || 48,
        pdfUrl,
        pages: Number(issue.pages) || 0,
        bytes: Number(issue.bytes) || 0,
        sha256,
        storyCount: Number(issue.storyCount) || 0,
        documentaryImageCount: Number(issue.documentaryImageCount) || 0,
        coverImageUrl,
        coverImageCredit: expectedViewId === 'nature' ? safeText(issue.coverImageCredit, 500) : '',
        coverImageCaption: expectedViewId === 'nature' ? safeText(issue.coverImageCaption, 500) : '',
        customRequest: safeText(issue.customRequest, 1200),
        customRequestReceipt: validateReceipt(issue.customRequestReceipt)
      });
    }
    return Object.freeze({ viewId: expectedViewId, generatedAt: safeText(payload.generatedAt, 80), issues: Object.freeze(issues) });
  }

  window.LiveEarthUniversalEditorialEngine = Object.freeze({
    name: ENGINE,
    version: VERSION,
    validateFeed,
    validateCatalog,
    safeText,
    safeHttps
  });
  window.__liveEarthUniversalEditorialEngineInstalled = true;
  window.dispatchEvent(new Event('live-earth-universal-editorial-engine-ready'));
})();
