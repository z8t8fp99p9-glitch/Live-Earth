// LIVE // EARTH: low-precision on-device current-day astronomy preview.
const DAY=86400000,rad=Math.PI/180,deg=180/Math.PI,norm=x=>((x%360)+360)%360;
export const dayKey=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const start=d=>new Date(d.getFullYear(),d.getMonth(),d.getDate());
function sunCoords(date){const jd=date.getTime()/DAY+2440587.5,t=(jd-2451545)/36525,L=norm(280.46646+t*(36000.76983+t*.0003032)),M=norm(357.52911+t*(35999.05029-.0001537*t)),e=.016708634-t*(.000042037+.0000001267*t),C=Math.sin(M*rad)*(1.914602-t*(.004817+.000014*t))+Math.sin(2*M*rad)*(.019993-.000101*t)+Math.sin(3*M*rad)*.000289,omega=125.04-1934.136*t,lambda=L+C-.00569-.00478*Math.sin(omega*rad),sec=21.448-t*(46.815+t*(.00059-t*.001813)),obliq=23+(26+sec/60)/60+.00256*Math.cos(omega*rad),decl=Math.asin(Math.sin(obliq*rad)*Math.sin(lambda*rad)),y=Math.tan(obliq*rad/2)**2,eq=4*deg*(y*Math.sin(2*L*rad)-2*e*Math.sin(M*rad)+4*e*y*Math.sin(M*rad)*Math.cos(2*L*rad)-.5*y*y*Math.sin(4*L*rad)-1.25*e*e*Math.sin(2*M*rad));return{decl,eq,lambda}}
export function sunPosition(date,lat,lon){const c=sunCoords(date),mins=date.getHours()*60+date.getMinutes()+date.getSeconds()/60,ts=((mins+c.eq+4*lon)%1440+1440)%1440,ha=(ts/4-180)*rad,phi=lat*rad,alt=Math.asin(Math.sin(phi)*Math.sin(c.decl)+Math.cos(phi)*Math.cos(c.decl)*Math.cos(ha)),az=norm(Math.atan2(Math.sin(ha),Math.cos(ha)*Math.sin(phi)-Math.tan(c.decl)*Math.cos(phi))*deg+180);return{altitude:alt*deg,azimuth:az}}
function solarDay(lat,lon,date){const c=sunCoords(new Date(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate(),12))),noon=720-4*lon-c.eq,phi=lat*rad,cz=(Math.cos(90.833*rad)-Math.sin(phi)*Math.sin(c.decl))/(Math.cos(phi)*Math.cos(c.decl));if(cz>1)return{sunrise:null,sunset:null,solarNoon:null,daylightMinutes:0,polar:'polar night'};if(cz< -1)return{sunrise:null,sunset:null,solarNoon:null,daylightMinutes:1440,polar:'midnight sun'};const h=deg*Math.acos(cz),at=m=>{const d=new Date(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate()));d.setUTCMinutes(Math.round(m));return d.toISOString()};return{sunrise:at(noon-4*h),sunset:at(noon+4*h),solarNoon:at(noon),daylightMinutes:Math.round(8*h),polar:null}}
function moonPosition(date,lat,lon){const days=date.getTime()/DAY-10957.5,L=norm(218.316+13.176396*days),M=norm(134.963+13.064993*days),F=norm(93.272+13.229350*days),lambda=L+6.289*Math.sin(M*rad),beta=5.128*Math.sin(F*rad),eps=(23.439-.0000004*days)*rad,lam=lambda*rad,bet=beta*rad,ra=Math.atan2(Math.sin(lam)*Math.cos(eps)-Math.tan(bet)*Math.sin(eps),Math.cos(lam)),dec=Math.asin(Math.sin(bet)*Math.cos(eps)+Math.cos(bet)*Math.sin(eps)*Math.sin(lam)),gmst=norm(280.16+360.9856235*days),ha=(gmst+lon-ra*deg)*rad,phi=lat*rad,alt=Math.asin(Math.sin(phi)*Math.sin(dec)+Math.cos(phi)*Math.cos(dec)*Math.cos(ha)),az=norm(Math.atan2(Math.sin(ha),Math.cos(ha)*Math.sin(phi)-Math.tan(dec)*Math.cos(phi))*deg+180),sun=sunCoords(date),sunLon=Math.atan2(Math.sin(sun.lambda*rad)*Math.cos(eps),Math.cos(sun.lambda*rad)),elong=Math.acos(Math.max(-1,Math.min(1,Math.sin(dec)*Math.sin(sun.decl)+Math.cos(dec)*Math.cos(sun.decl)*Math.cos(ra-sunLon)))),illum=(1-Math.cos(elong))/2,age=((days-5.0)%29.530588853+29.530588853)%29.530588853,p=age/29.530588853;let phase=p<.035||p>.965?'New Moon':p<.22?'Waxing Crescent':p<.28?'First Quarter':p<.47?'Waxing Gibbous':p<.53?'Full Moon':p<.72?'Waning Gibbous':p<.78?'Last Quarter':'Waning Crescent';return{altitude:alt*deg,azimuth:az,illumination:illum,age,phase}}
function riseSet(fn,lat,lon,date){const s=start(date).getTime(),e=new Date(date.getFullYear(),date.getMonth(),date.getDate()+1).getTime(),step=600000;let prev=fn(new Date(s),lat,lon).altitude,rise=null,set=null;for(let t=s+step;t<=e;t+=step){const v=fn(new Date(t),lat,lon).altitude;if(prev<=0&&v>0&&!rise)rise=new Date(t).toISOString();if(prev>0&&v<=0&&!set)set=new Date(t).toISOString();prev=v}return{rise,set}}
export function calculateAstronomy(lat,lon,date=new Date()){const s=sunPosition(date,lat,lon),m=moonPosition(date,lat,lon),sr=solarDay(lat,lon,date),mr=riseSet(moonPosition,lat,lon,date);return{date:dayKey(date),calculatedAt:Date.now(),sun:{...sr,altitudeDegrees:+s.altitude.toFixed(1),azimuthDegrees:+s.azimuth.toFixed(1)},moon:{phase:m.phase,illuminationPercent:Math.round(m.illumination*100),ageDays:+m.age.toFixed(1),moonrise:mr.rise,moonset:mr.set,altitudeDegrees:+m.altitude.toFixed(1),azimuthDegrees:+m.azimuth.toFixed(1)}}}

/* Append this snippet to astronomy.js after its existing declarations.
   Low-precision, on-device crossing estimate; this does not claim ephemeris accuracy. */
export { moonPosition };
export function moonRiseSetInterval(lat, lon, now = new Date()) {
  if (!Number.isFinite(lat) || !Number.isFinite(lon) ||
      lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
  const STEP = 5 * 60 * 1000;
  const nowMs = now.getTime();
  const from = nowMs - 36 * 60 * 60 * 1000;
  const to = nowMs + 36 * 60 * 60 * 1000;
  const events = [];
  let previousTime = from;
  let previousAltitude = moonPosition(new Date(previousTime), lat, lon).altitude;
  for (let t = from + STEP; t <= to; t += STEP) {
    const altitude = moonPosition(new Date(t), lat, lon).altitude;
    if (previousAltitude <= 0 && altitude > 0) {
      const fraction = previousAltitude / (previousAltitude - altitude);
      events.push({ type: "rise", time: previousTime + STEP * fraction });
    } else if (previousAltitude > 0 && altitude <= 0) {
      const fraction = previousAltitude / (previousAltitude - altitude);
      events.push({ type: "set", time: previousTime + STEP * fraction });
    }
    previousTime = t;
    previousAltitude = altitude;
  }
  const altitudeNow = moonPosition(now, lat, lon).altitude;
  let riseTime = null;
  let setTime = null;
  if (altitudeNow > 0) {
    for (const event of events) {
      if (event.type === "rise" && event.time <= nowMs) riseTime = event.time;
      if (event.type === "set" && event.time > nowMs) { setTime = event.time; break; }
    }
  } else {
    const rise = events.find(event => event.type === "rise" && event.time > nowMs);
    if (rise) {
      riseTime = rise.time;
      const set = events.find(event => event.type === "set" && event.time > rise.time);
      if (set) setTime = set.time;
    }
  }
  if (!Number.isFinite(riseTime) || !Number.isFinite(setTime) || setTime <= riseTime) return null;
  return {
    rise: new Date(riseTime),
    set: new Date(setTime),
    aboveHorizonNow: altitudeNow > 0,
    approximate: true
  };
}
