# Weather Art assets

This folder is reserved exclusively for the LIVE // EARTH Weather view's Live Art studio.

Included in this first pack:
- `rainy-tea-afternoon-001.webp` — 1200 × 840, exact 10:7.
- `art-library.json` — metadata for the staged artwork.
- `ART-DIRECTION.md` — reusable art direction for all future illustrations.

**Integration status:** The artwork is staged in the Weather-only app path. The current `Weather/weather-view.js` still uses its procedural Live Art painter; it does not yet load this WebP. A narrow painter mapping/load change is still required before the artwork appears in the card. The existing procedural study should remain as the fallback.

Future generated artworks should be added here with unique IDs and matching catalog entries. Do not move these assets into a global directory.
