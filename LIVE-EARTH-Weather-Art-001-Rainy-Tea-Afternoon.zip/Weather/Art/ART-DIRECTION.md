# LIVE // EARTH — Weather Art Direction

**Scope:** `Weather/Art/` and the Weather view's Live Art studio only.

## Creative idea

**Weather is the setting. Everyday life is the subject. Calmness is the feeling.**

Create original Japanese minimalist ink-and-wash digital illustrations about the small rituals, objects, places and feelings that weather brings into daily life. Do not merely draw a weather symbol or a generic landscape.

Examples:
- Rain: warm tea by a rain-streaked window, an umbrella beside a doorway, droplets resting on leaves.
- Storm: shelter, a lantern-lit room, trees bending in the wind, watching the storm from safety.
- Sunshine: a quiet picnic, laundry in a soft breeze, a garden afternoon.
- Snow: warm drinks, footprints, a window looking onto a quiet garden.
- Wind: a wind chime, flowing curtains, a kite, leaves moving along a path.
- Fog: a solitary walk, a bridge disappearing into mist, a quiet morning ritual.

## Visual language

- Japanese minimalist ink-and-wash digital illustration.
- Confident, expressive brush strokes; clean enough to read on a phone.
- Recognisable objects and small details, but no fussy micro-detail.
- Soft ink-wash atmosphere and gentle tonal variation.
- Restrained vermilion/red accents against warm paper, charcoal ink and muted greys.
- A little warmth, charm and human feeling; not museum reproduction, photorealism, cartoon icons or flat pictograms.
- Let the scene tell a small visual story. Objects should feel related, not randomly assembled.

## Composition and delivery

- Exact canvas ratio: **10:7 landscape**.
- The scene should have presence and fill most of the available artwork area, with comfortable paper margins.
- Use the approved rainy tea scene as a quality and mood reference, not a template to copy.
- Keep artwork palettes fixed across day/night. Weather may select a different scene, but must not automatically recolour an existing illustration.
- App asset format: optimized WebP. Keep a high-quality source master separately when useful.
- Store only under `Weather/Art/`. Do not put Weather artwork in a global asset folder.
- Every new artwork request creates a new original image and a new library record. Do not reuse the same art for every condition.

## App integration boundaries

- Intended render target: Weather view's **Live Art studio card** only.
- Do not replace or alter the main live-weather landscape painter.
- Preserve existing Weather typography, readings, layout, safe areas, 10:7 Live Art frame, fixed palette, Location privacy and Orb dock.
- No runtime AI generation, remote image service or external art dependency.
- Keep the existing local procedural Live Art study available as a fallback until each local artwork asset is successfully loaded and verified offline.
- This folder package stages approved artwork files; the current painter still needs an explicit source-code mapping before an image appears in the Live Art card.
