const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(
  path.join(__dirname, '..', 'Weather', 'weather-view.js'),
  'utf8'
);

assert.ok(source.includes('@media (orientation:landscape) and (min-width:650px)'));
assert.ok(source.includes('grid-template-columns:minmax(218px,.42fr) minmax(0,1fr);'));
assert.ok(source.includes('grid-template-areas:"forecast artwork";'));
assert.ok(source.includes('grid-area:forecast;'));
assert.ok(source.includes('grid-area:artwork;'));
assert.ok(source.includes('grid-template-rows:auto minmax(82px,1fr) auto;'));
assert.ok(source.includes('grid-template-areas:"hero" "scene" "summary";'));
assert.ok(source.includes('height:100%;'));
assert.ok(source.includes('--le-weather-landscape-height:clamp(190px,calc(100svh - env(safe-area-inset-top) - var(--le-weather-dock-clearance,126px) - 80px),292px);'));
assert.ok(source.includes('width:min(100%,calc((var(--le-weather-landscape-height) - 20px) * 1.428571));'));
assert.ok(source.includes('aspect-ratio:10 / 7;'));
assert.ok(source.includes('place-items:center;'));
assert.ok(source.includes('justify-self:center;'));
assert.ok(source.includes('align-self:center;'));
assert.ok(source.includes('font-size:clamp(58px,6.8vw,72px)'));
assert.ok(source.includes('font-size:clamp(14px,1.7vw,17px)'));
assert.ok(source.includes('white-space:normal;\n          overflow:visible;\n          text-overflow:clip;'));
assert.ok(source.includes('var(--le-weather-dock-clearance'));

const dashboard = source.indexOf('<div class="le-weather-dashboard">');
const forecast = source.indexOf('<div class="le-weather-forecast-column">', dashboard);
const hero = source.indexOf('<section class="le-weather-hero"', forecast);
const scene = source.indexOf('<div class="le-weather-art-stage"', forecast);
const summary = source.indexOf('<section class="le-weather-summary"', forecast);
const artwork = source.indexOf('<div class="le-weather-art-column">', summary);
const studio = source.indexOf('<section class="le-weather-studio"', artwork);

assert.ok(dashboard >= 0 && forecast > dashboard);
assert.ok(hero > forecast && scene > hero && summary > scene);
assert.ok(artwork > summary && studio > artwork);
assert.ok(source.includes('padding-left:max(env(safe-area-inset-left),clamp(40px,5.8vw,64px))'));
assert.ok(source.includes('padding-right:max(env(safe-area-inset-right),clamp(40px,5.8vw,64px))'));
assert.ok(source.includes('grid-template-columns:minmax(218px,.42fr) minmax(0,1fr);'));
assert.ok(source.includes('font-size:clamp(12px,1.35vw,14px)'));
assert.ok(source.includes('font-size:clamp(22px,2.8vw,31px)'));
assert.ok(source.includes('function drawMinimalLandscape(p,t)'));
assert.ok(source.includes('drawMinimalLandscape(p,t);'));
assert.ok(!source.includes('const compactLandscape='));
assert.ok(!source.includes('le-weather-hourly'));
assert.ok(!source.includes('NEXT 6 HOURS'));
assert.ok(!source.includes('hourly:'));

// Shared Orb dock is measured only; its styles and geometry remain outside Weather ownership.
assert.ok(source.includes("document.getElementById('le-feature-dock')"));
assert.ok(source.includes('function syncDockClearance()'));
assert.ok(!/#le-feature-dock\s*\{/.test(source));
assert.ok(!/weatherDock\.style\.(?:bottom|top|left|right|transform|width|height)/.test(source));

console.log('Weather 42/58 overview, centred 10:7 Live Art, shared minimalist scene, notched-safe masthead and locked Orb dock contracts passed.');
