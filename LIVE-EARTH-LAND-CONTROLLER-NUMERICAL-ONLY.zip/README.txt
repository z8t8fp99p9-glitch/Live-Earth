LIVE // EARTH — Land controller patch
=====================================

Target branch: main
Target path: Land/land-view-controller.js

This patch replaces the Land view shell with a numerical-only controller
following the existing Atmosphere / Oceans / Atmospheric Composition view
patterns and shared Earth Engine lifecycle.

What it does:
- Preserves the existing Land world id and shared interactive Earth Engine.
- Adds a compact dataset selector for the ten registered Land topics.
- Enables Land temperature only, because it is the only Land dataset with
  collected numerical records in the current repository.
- Loads and validates the six NASA POWER regional point samples from the
  Central-Database current-values store.
- Displays numeric values, coordinates, observation time and provenance.
- Leaves the other nine controls visible but disabled until source adapters
  and numerical records exist.
- Does not create a raster, interpolate samples, fabricate values, or load
  imagery datasets.

Validation:
- JavaScript syntax checked with Node.js (`node --check`).
- Source inspected against the current main branch at HEAD:
  23bc699b0f41052a126c1b7a3d7dc1752d2b5540

Installation:
Replace only Land/land-view-controller.js with the file in this ZIP.
Do not upload the README or this package folder into the repository.
No GitHub commit, push, or deployment was performed by the assistant.
