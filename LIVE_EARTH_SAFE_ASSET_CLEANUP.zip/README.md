# LIVE // EARTH — Safe asset cleanup package

Repository: `z8t8fp99p9-glitch/Live-Earth`
Branch: `main`
Audited HEAD: `3ea8ba69806d03d6ddab5aadf6731a72e6fe4817`

## What this package does

This is a **local cleanup patch only**. It does not connect to GitHub, push, commit, stage, or change any remote branch.

The apply scripts:
1. Require the repository to be on `main` at the exact audited HEAD above.
2. Verify every target file against its recorded Git blob SHA.
3. Stop before making changes if any preflight check fails.
4. Copy all selected files into a timestamped backup directory beside the repository.
5. Delete only the eight paths listed in `CLEANUP_MANIFEST.json`.
6. Leave the working tree unstaged.

## Apply

From the root of your local `Live-Earth` clone:

- macOS / Linux: `bash apply-cleanup.sh`
- Windows PowerShell: `./apply-cleanup.ps1`

Do not run against a different branch or a newer checkout. If `main` has moved, stop and re-audit against the new HEAD first.

## Roll back

The script prints the backup directory it created. To restore:

- macOS / Linux: `bash restore-cleanup.sh "/path/to/backup-directory"`
- Windows PowerShell: `./restore-cleanup.ps1 -BackupDirectory "/path/to/backup-directory"`

The restore scripts copy the backed-up originals back to their exact repository-relative paths. They do not stage or commit.

## Deliberately excluded

`Stacks/Assets/feature-wallpaper.png` is a review-only candidate. It is not included in automatic deletion because it may be an intentional feature asset and the full repository reference graph was not exhaustively available.

Also preserved: the Pavilion 002/003 JSON source records, the Pavilion 002 master-scale proof, Pavilion 003 stage-mask atlas, Pavilion 003 master image, active Weather artwork, approved style references, and all app-shell/runtime assets.

## Audit scope and confidence

The current `sw.js`, `index.html`, `manifest.json`, active Weather renderer, Weather art library, Sun controller, Stacks feature view, and relevant view controllers were inspected. The current service-worker shell does not list any automatic deletion target. The current Sun controller explicitly loads `Sun/sun-surface-shared.webp`.

The Weather art library explicitly marks Pavilion 002 as historical and unsupported by the active renderer, and Pavilion 003's schema-v3 renderer as retired. Exact duplicate pairs were identified by matching Git blob SHAs.

Because this package was prepared without a complete downloadable repository tree, it uses conservative exclusions and strict SHA preflight checks. Review the manifest before running.
