#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD="3ea8ba69806d03d6ddab5aadf6731a72e6fe4817"
EXPECTED_BRANCH="main"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "ERROR: run inside the Live-Earth git repository."; exit 1; }
cd "$ROOT"

ACTUAL_BRANCH="$(git branch --show-current)"
ACTUAL_HEAD="$(git rev-parse HEAD)"
if [[ "$ACTUAL_BRANCH" != "$EXPECTED_BRANCH" ]]; then
  echo "ERROR: expected branch $EXPECTED_BRANCH; found $ACTUAL_BRANCH"; exit 1
fi
if [[ "$ACTUAL_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: audited HEAD mismatch. Expected $EXPECTED_HEAD, found $ACTUAL_HEAD"; exit 1
fi

declare -a PATHS=(
  "Sun/sun-sphere-equirectangular.png"
  "Weather/Art/weather-japanese-night.webp"
  "Weather/Art/weather-world-master-square.webp"
  "Weather/Art/References/clear-maple-pavilion-002-90pct-preview.png"
  "Weather/Art/References/clear-weather-master-001.jpg"
  "Weather/Art/References/clear-maple-pavilion-002-pressure-stroke-preview.png"
  "Weather/Art/References/clear-maple-pavilion-003-brush-reveal-preview.png"
  "Weather/Art/References/clear-maple-pavilion-003-stage-preview.png"
)
declare -a SHAS=(
  "8542be7eafd438738a0793ee62519b36d5c8ac60"
  "cd10ff789cdd35680157d2222588efcee4260669"
  "bb3566eb8496ef0b2a853b42f449c350fff2f2bb"
  "4b0242262ce3228854f59777f17a06ac58099f9a"
  "c0d4f6955a7506bfc3e53657f79c7c16a557e209"
  "76edfe434471b298eeee12f5c4edfffbc9b8f3b5"
  "a8558ea17da06d6e0922998931b6763cdd6b6a62"
  "524e40ab36cec5840f43155816d4fe117748ac94"
)
if [[ "${#PATHS[@]}" -ne "${#SHAS[@]}" ]]; then echo "ERROR: manifest mismatch."; exit 1; fi

# Full preflight first: no file is changed unless every path and blob matches.
for i in "${!PATHS[@]}"; do
  p="${PATHS[$i]}"; expected="${SHAS[$i]}"
  [[ -f "$p" ]] || { echo "ERROR: missing target: $p"; exit 1; }
  actual="$(git hash-object -- "$p")"
  [[ "$actual" == "$expected" ]] || { echo "ERROR: SHA mismatch for $p (expected $expected, got $actual)"; exit 1; }
done

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="$ROOT/../Live-Earth-asset-cleanup-backup-$STAMP"
mkdir -p "$BACKUP"
for p in "${PATHS[@]}"; do
  mkdir -p "$BACKUP/$(dirname "$p")"
  cp -p "$p" "$BACKUP/$p"
done

for p in "${PATHS[@]}"; do rm -- "$p"; done
printf '%s\n' "$EXPECTED_HEAD" > "$BACKUP/AUDITED_HEAD.txt"
printf '%s\n' "$ACTUAL_BRANCH" > "$BACKUP/BRANCH.txt"
echo "Cleanup complete. Backup: $BACKUP"
echo "No Git staging, commit, or remote write was performed."
