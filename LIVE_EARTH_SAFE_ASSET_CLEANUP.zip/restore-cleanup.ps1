param([Parameter(Mandatory=$true)][string]$BackupDirectory)
$ErrorActionPreference = "Stop"
if (-not (Test-Path -LiteralPath $BackupDirectory -PathType Container)) { throw "Backup directory not found." }
$Root = (& git rev-parse --show-toplevel 2>$null)
if (-not $Root) { throw "Run this script inside the Live-Earth git repository." }
Set-Location $Root
Get-ChildItem -LiteralPath $BackupDirectory -Recurse -File | Where-Object {
  $_.Name -ne "AUDITED_HEAD.txt" -and $_.Name -ne "BRANCH.txt"
} | ForEach-Object {
  $Relative = $_.FullName.Substring($BackupDirectory.TrimEnd("\/").Length + 1)
  $Destination = Join-Path $Root $Relative
  New-Item -ItemType Directory -Force -Path (Split-Path $Destination -Parent) | Out-Null
  Copy-Item -LiteralPath $_.FullName -Destination $Destination -Force
}
Write-Host "Restored files from: $BackupDirectory"
Write-Host "No Git staging, commit, or remote write was performed."
