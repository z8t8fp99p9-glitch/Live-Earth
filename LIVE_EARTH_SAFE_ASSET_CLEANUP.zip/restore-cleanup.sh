#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "Usage: bash restore-cleanup.sh /path/to/backup-directory"; exit 2; fi
BACKUP="$1"
[[ -d "$BACKUP" ]] || { echo "ERROR: backup directory not found."; exit 1; }
ROOT="$(git rev-parse --show-toplevel 2>/dev/null)" || { echo "ERROR: run inside the Live-Earth git repository."; exit 1; }
cd "$ROOT"
while IFS= read -r -d '' file; do
  rel="${file#"$BACKUP"/}"
  mkdir -p "$(dirname "$rel")"
  cp -p "$file" "$rel"
done < <(find "$BACKUP" -type f ! -name 'AUDITED_HEAD.txt' ! -name 'BRANCH.txt' -print0)
echo "Restored files from: $BACKUP"
echo "No Git staging, commit, or remote write was performed."
