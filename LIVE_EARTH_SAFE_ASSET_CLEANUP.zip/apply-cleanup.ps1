$ErrorActionPreference = "Stop"
$ExpectedHead = "3ea8ba69806d03d6ddab5aadf6731a72e6fe4817"
$ExpectedBranch = "main"
$Root = (& git rev-parse --show-toplevel 2>$null)
if (-not $Root) { throw "Run this script inside the Live-Earth git repository." }
Set-Location $Root
$Branch = (& git branch --show-current).Trim()
$Head = (& git rev-parse HEAD).Trim()
if ($Branch -ne $ExpectedBranch) { throw "Expected branch $ExpectedBranch; found $Branch" }
if ($Head -ne $ExpectedHead) { throw "Audited HEAD mismatch. Expected $ExpectedHead; found $Head" }

$Targets = @(
  @{ Path = "Sun/sun-sphere-equirectangular.png"; Sha = "8542be7eafd438738a0793ee62519b36d5c8ac60" }
  @{ Path = "Weather/Art/weather-japanese-night.webp"; Sha = "cd10ff789cdd35680157d2222588efcee4260669" }
  @{ Path = "Weather/Art/weather-world-master-square.webp"; Sha = "bb3566eb8496ef0b2a853b42f449c350fff2f2bb" }
  @{ Path = "Weather/Art/References/clear-maple-pavilion-002-90pct-preview.png"; Sha = "4b0242262ce3228854f59777f17a06ac58099f9a" }
  @{ Path = "Weather/Art/References/clear-weather-master-001.jpg"; Sha = "c0d4f6955a7506bfc3e53657f79c7c16a557e209" }
  @{ Path = "Weather/Art/References/clear-maple-pavilion-002-pressure-stroke-preview.png"; Sha = "76edfe434471b298eeee12f5c4edfffbc9b8f3b5" }
  @{ Path = "Weather/Art/References/clear-maple-pavilion-003-brush-reveal-preview.png"; Sha = "a8558ea17da06d6e0922998931b6763cdd6b6a62" }
  @{ Path = "Weather/Art/References/clear-maple-pavilion-003-stage-preview.png"; Sha = "524e40ab36cec5840f43155816d4fe117748ac94" }
)
# Full preflight before any backup or deletion.
foreach ($Target in $Targets) {
  if (-not (Test-Path -LiteralPath $Target.Path -PathType Leaf)) { throw "Missing target: $($Target.Path)" }
  $Actual = (& git hash-object -- $Target.Path).Trim()
  if ($Actual -ne $Target.Sha) { throw "SHA mismatch for $($Target.Path): expected $($Target.Sha), got $Actual" }
}
$Stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$Backup = Join-Path (Split-Path $Root -Parent) "Live-Earth-asset-cleanup-backup-$Stamp"
New-Item -ItemType Directory -Path $Backup | Out-Null
foreach ($Target in $Targets) {
  $Destination = Join-Path $Backup $Target.Path
  New-Item -ItemType Directory -Force -Path (Split-Path $Destination -Parent) | Out-Null
  Copy-Item -LiteralPath $Target.Path -Destination $Destination
}
foreach ($Target in $Targets) { Remove-Item -LiteralPath $Target.Path }
Set-Content -LiteralPath (Join-Path $Backup "AUDITED_HEAD.txt") -Value $ExpectedHead
Set-Content -LiteralPath (Join-Path $Backup "BRANCH.txt") -Value $Branch
Write-Host "Cleanup complete. Backup: $Backup"
Write-Host "No Git staging, commit, or remote write was performed."
