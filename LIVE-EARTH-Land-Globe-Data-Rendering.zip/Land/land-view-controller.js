/* LIVE // EARTH — Land View Controller.
   Globe-first Land observatory. Mirrors the accepted Atmosphere/Oceans view
   composition and complete Earth Engine interaction model, while preserving
   Land's verified sparse numerical point-sample data semantics.
*/
(() => {
  'use strict';
  const flag = '__liveEarthLandViewControllerInstalled';
  if (window[flag]) return;

  const runtime = window.LiveEarthStacksFeatureRuntime;
  if (!runtime || typeof runtime.registerFeature !== 'function') {
    console.warn('[LIVE // EARTH] Land controller is waiting for the feature-view runtime.');
    return;
  }

  const WORLD = {
    id: 'land',
    title: 'Land',
    symbol: '⌁',
    message: 'Select a Land dataset to inspect its verified regional observations.'
  };
  const VALUES_BASE_URL = 'https://raw.githubusercontent.com/z8t8fp99p9-glitch/Live-Earth/main/Data/Central-Database/values/';
  const LAND_DATASETS = {
    land_temperature: {
      id:'land_temperature', datasetId:'earth.land.land_temperature',
      label:'Land temperature', units:'degree_C', displayUnit:'°C',
      sourceId:'nasa_power_daily', parameter:'T2M', kind:'numeric',
      sourceLabel:'NASA POWER daily 2 m air temperature',
      description:'Daily 2 m air temperature at six regional sample points.'
    },
    vegetation_health: {
      id:'vegetation_health', datasetId:'earth.land.vegetation_health',
      label:'Vegetation activity', units:'1', displayUnit:'NDVI',
      sourceId:'noaa_cdr_viirs_ndvi_daily', kind:'ndvi',
      sourceLabel:'NOAA CDR VIIRS Normalized Difference Vegetation Index',
      description:'NDVI indicates satellite-derived vegetation greenness/activity; it is not a direct diagnosis of plant health.'
    },
    forest_change: {
      id:'forest_change', datasetId:'earth.land.forest_change',
      label:'Forest change', units:'year', displayUnit:'loss year',
      sourceId:'hansen_global_forest_change_2025_v1_13', kind:'forest',
      sourceLabel:'Hansen Global Forest Change 2025 v1.13',
      description:'Point samples of gross stand-replacement forest loss during 2001–2025. Zero means no detected loss at the sampled pixel.'
    }
  };

  const DATASET_OPTIONS = [
    { id:'land_temperature', label:'Land temperature', icon:'temperature', color:'#ff9c68', available:true },
    { id:'soil_moisture', label:'Soil moisture', icon:'moisture', color:'#71c9f4' },
    { id:'soil_properties', label:'Soil properties', icon:'soil', color:'#c2a080' },
    { id:'elevation', label:'Elevation', icon:'elevation', color:'#d2bd91' },
    { id:'terrain', label:'Terrain', icon:'terrain', color:'#a9c6d8' },
    { id:'land_cover', label:'Land cover', icon:'cover', color:'#8bdd9a' },
    { id:'vegetation_health', label:'Vegetation activity', icon:'vegetation', color:'#a8e78e', available:true },
    { id:'forest_change', label:'Forest change', icon:'forest', color:'#78d6a3', available:true },
    { id:'surface_reflectance', label:'Surface reflectance', icon:'reflectance', color:'#e5d48e' },
    { id:'urban_expansion', label:'Urban expansion', icon:'urban', color:'#c4b2ff' }
  ];

  const REGION_NAMES = {
    north_america:'North America',
    south_america:'South America',
    europe_north_africa:'Europe & North Africa',
    east_africa:'East Africa',
    south_asia:'South Asia',
    east_asia_pacific:'East Asia & Pacific'
  };
  const REGION_ORDER = [
    'north_america','south_america','europe_north_africa',
    'east_africa','south_asia','east_asia_pacific'
  ];

  const ICONS = {
    temperature:'<path d="M10 14.5V5a2 2 0 1 1 4 0v9.5a4 4 0 1 1-4 0Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M12 10v8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
    moisture:'<path d="M12 3.5s-6 6.4-6 10.5a6 6 0 0 0 12 0c0-4.1-6-10.5-6-10.5Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M9 15.2a3.2 3.2 0 0 0 3.2 3.1" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    soil:'<path d="M4 7h16M4 12h16M4 17h16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M7 7v5m5 0v5m5-10v5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>',
    elevation:'<path d="m3 18 6.2-10 3.1 5 2.2-3.2L21 18H3Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="m7.2 11.2 2 1.1 1.2-1.5m3.4 1.3 1.7 1.1 1.2-1" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>',
    terrain:'<path d="M3 17c2.5-5 4.5-5 7 0s4.5 5 7 0 4.5-5 4-5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M3 11c2.5-5 4.5-5 7 0s4.5 5 7 0 4.5-5 4-5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    cover:'<path d="M19.5 4.5C11 4.5 5 7.4 5 13.2c0 3.3 2.3 5.3 5.3 5.3 5.8 0 8.7-6 9.2-14Z" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4 20c3.2-4.4 6.6-7.1 12-10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    vegetation:'<path d="M12 20v-8m0 3c-4.5 0-7-2.5-7-7 4.5 0 7 2.5 7 7Zm0-3c0-4.5 2.5-7 7-7 0 4.5-2.5 7-7 7Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    forest:'<path d="m12 3 6 8h-3l4 6H5l4-6H6l6-8Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 17v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    reflectance:'<circle cx="12" cy="12" r="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3m13 0h3M5.3 5.3l2.1 2.1m9.2 9.2 2.1 2.1m0-13.4-2.1 2.1m-9.2 9.2-2.1 2.1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    urban:'<path d="M4 20V8h6v12M10 20V4h10v16M2 20h20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M7 11h.1M7 14h.1m7-6h.1m3 0h.1m-3 4h.1m3 0h.1m-3 4h.1m3 0h.1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
  };

  function installHudStyle() {
    if (document.getElementById('le-land-cinematic-hud')) return;
    const style = document.createElement('style');
    style.id = 'le-land-cinematic-hud';
    style.textContent = `
      .le-sfv--land .le-sfv-panel {
        display:flex; flex-direction:column; align-items:stretch; overflow:hidden;
        background:transparent!important; backdrop-filter:none!important;
        -webkit-backdrop-filter:none!important;
        padding:calc(env(safe-area-inset-top) + clamp(66px,9vmin,82px)) clamp(15px,4vw,32px) 0;
      }
      .le-sfv--land .le-sfv-head { margin-bottom:9px; }
      .le-land-scene-title {
        position:absolute; z-index:3; top:12vh; top:12svh;
        left:50%; right:auto; width:min(84vw,620px); box-sizing:border-box;
        transform:translateX(-50%); display:flex; align-items:center;
        justify-content:center; gap:clamp(12px,3vw,24px);
        color:rgba(226,241,250,.88); pointer-events:none; user-select:none;
      }
      .le-land-scene-title::before,.le-land-scene-title::after {
        content:""; height:1px; flex:1 1 0; min-width:12px;
        background:linear-gradient(90deg,transparent,rgba(148,190,215,.46));
      }
      .le-land-scene-title::after { background:linear-gradient(90deg,rgba(148,190,215,.46),transparent); }
      .le-land-scene-title span {
        font:500 clamp(12px,3.25vmin,17px)/1.2 system-ui,-apple-system,sans-serif;
        letter-spacing:clamp(.24em,1.15vmin,.38em); white-space:nowrap;
        text-shadow:0 0 14px rgba(122,190,226,.20);
      }
      .le-land-scene-title i {
        position:absolute; left:16%; right:16%; top:calc(100% + 13px); height:1px;
        background:linear-gradient(90deg,transparent,rgba(50,155,232,.30) 28%,rgba(69,190,255,.9) 50%,rgba(50,155,232,.30) 72%,transparent);
        box-shadow:0 0 8px rgba(30,151,255,.45); font-style:normal;
      }
      .le-land-scene-title i::after {
        content:""; position:absolute; left:50%; top:50%; width:5px; height:5px;
        border-radius:50%; transform:translate(-50%,-50%); background:#a8eaff;
        box-shadow:0 0 6px 2px #168fff,0 0 15px 5px rgba(20,133,255,.55);
      }
      .le-land-hud-toggle {
        position:absolute; z-index:5; top:calc(env(safe-area-inset-top) + 14px);
        right:max(14px,env(safe-area-inset-right)); display:grid; place-items:center;
        width:clamp(46px,6vmin,52px); height:clamp(46px,6vmin,52px);
        min-width:44px; min-height:44px; padding:0; aspect-ratio:1;
        border:1px solid rgba(135,205,239,.48); border-radius:50%; color:#eaf7ff;
        background:radial-gradient(circle at 34% 25%,rgba(112,207,245,.18),transparent 48%),linear-gradient(155deg,rgba(13,39,61,.94),rgba(3,12,24,.96));
        box-shadow:inset 0 1px 0 rgba(255,255,255,.16),inset 0 0 0 3px rgba(122,205,240,.035),0 0 18px rgba(54,174,231,.14),0 5px 18px rgba(0,0,0,.28);
        backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px);
        cursor:pointer; touch-action:manipulation; pointer-events:auto;
        transition:background .2s ease,border-color .2s ease,box-shadow .2s ease,transform .2s ease;
      }
      .le-land-hud-toggle:active { transform:scale(.94); }
      .le-land-hud-toggle:focus-visible { outline:2px solid #80d9f5; outline-offset:3px; }
      .le-land-hud-toggle-icon { width:19px; height:19px; flex:none; color:#a6e5ff; }
      .le-land-hud-toggle[aria-expanded="true"] { border-color:rgba(111,218,255,.78); box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 0 22px rgba(55,190,245,.25),0 5px 18px rgba(0,0,0,.28); }
      .le-land-dataset-orb-menu {
        position:absolute; z-index:6; top:calc(env(safe-area-inset-top) + 72px);
        right:max(14px,env(safe-area-inset-right)); display:grid;
        grid-template-columns:repeat(2,clamp(42px,5.8vmin,48px)); gap:8px;
        align-items:center; justify-items:center; width:max-content;
        max-height:min(68svh,440px); overflow-y:auto; overscroll-behavior:contain;
        padding:4px; scrollbar-width:none; opacity:0; visibility:hidden;
        pointer-events:none; transform:translateY(-7px) scale(.96);
        transform-origin:top center; transition:opacity .2s ease,transform .2s ease,visibility .2s ease;
      }
      .le-land-dataset-orb-menu::-webkit-scrollbar { display:none; }
      .le-land-dataset-orb-menu.is-open { opacity:1; visibility:visible; pointer-events:auto; transform:translateY(0) scale(1); }
      .le-land-dataset-orb {
        appearance:none; display:grid; place-items:center;
        width:clamp(42px,5.8vmin,48px); height:clamp(42px,5.8vmin,48px);
        min-width:42px; min-height:42px; padding:0; border-radius:50%;
        border:1px solid rgba(122,205,240,.42); color:#eaf7ff;
        background:radial-gradient(circle at 34% 24%,rgba(111,204,245,.2),transparent 52%),linear-gradient(155deg,rgba(12,37,58,.96),rgba(3,12,24,.97));
        box-shadow:inset 0 1px 0 rgba(255,255,255,.13),0 0 15px rgba(54,174,231,.13),0 4px 13px rgba(0,0,0,.28);
        backdrop-filter:blur(13px); -webkit-backdrop-filter:blur(13px);
        cursor:pointer; touch-action:manipulation;
        transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease,background .18s ease;
      }
      .le-land-dataset-orb:active { transform:scale(.92); }
      .le-land-dataset-orb:focus-visible { outline:2px solid #80d9f5; outline-offset:3px; }
      .le-land-dataset-orb.is-selected { border-color:rgba(112,225,210,.9); box-shadow:inset 0 0 0 1px rgba(112,225,210,.22),0 0 19px rgba(72,220,196,.28),0 4px 13px rgba(0,0,0,.28); background:linear-gradient(155deg,rgba(15,65,72,.96),rgba(3,18,31,.98)); }
      .le-land-dataset-orb:disabled { opacity:.48; cursor:progress; }
      .le-land-dataset-orb-icon { width:21px; height:21px; display:block; }
      .le-sfv--land .le-sfv-panel.le-land-hud-hidden { opacity:0; visibility:hidden; pointer-events:none; transition:opacity .2s ease,visibility .2s ease; }
      .le-sfv--land .le-sfv-panel { transition:opacity .2s ease,visibility .2s ease; }
      .le-sfv--land.le-world-engine-host .le-sfv-panel { z-index:3; background:transparent!important; }
      .le-sfv--land .le-sfv-pill { margin-bottom:10px; }
      .le-sfv--land.le-world-engine-host .le-sfv-body {
        display:block; box-sizing:border-box; width:min(100%,680px); margin:auto auto 0;
        min-height:0; max-height:min(48dvh,540px); overflow-y:auto; overflow-x:hidden;
        overscroll-behavior:contain; -webkit-overflow-scrolling:touch;
        padding-bottom:calc(env(safe-area-inset-bottom) + 144px); scrollbar-width:none;
        pointer-events:none;
      }
      .le-sfv--land.le-world-engine-host .le-sfv-body::-webkit-scrollbar { display:none; }
      .le-sfv--land.le-world-engine-host .le-sfv-body > *,
      .le-sfv--land.le-world-engine-host .le-sfv-body :is(button,a,input,select,textarea,summary,[role="button"],.le-land-details,.le-land-scale-dock,.le-land-data-card) { pointer-events:auto; }
      .le-sfv--land .le-sfv-status {
        display:inline-block; width:auto; max-width:100%; margin:0 0 9px; padding:7px 11px;
        border-radius:999px; font-size:9px; line-height:1.35;
        background:rgba(3,13,24,.54); border-color:rgba(126,228,189,.22);
        backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
      }
      .le-sfv--land .le-sfv-card {
        padding:13px 15px; border-radius:17px; border-color:rgba(159,211,249,.19);
        background:linear-gradient(145deg,rgba(8,23,40,.80),rgba(3,10,20,.78));
        box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 10px 28px rgba(0,0,0,.22);
        backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px);
      }
      .le-sfv--land .le-sfv-card h2 { margin:0 0 4px; font-size:10px; letter-spacing:.12em; color:#a9c9de; text-transform:uppercase; }

      .le-land-scale-dock {
        container-type:inline-size; --land-action-space:42px; --land-track-gap:12px;
        --land-content-width:calc(100% - var(--land-action-space) - var(--land-track-gap));
        position:absolute; z-index:4; left:clamp(20px,4.5vw,48px); right:clamp(20px,4.5vw,48px);
        bottom:calc(env(safe-area-inset-bottom) + clamp(82px,12svh,112px));
        box-sizing:border-box; width:min(calc(100% - 40px),760px); margin:0 auto; padding:0;
        border:0; border-radius:0; color:#eff8ff; background:transparent; box-shadow:none;
        backdrop-filter:none; -webkit-backdrop-filter:none; pointer-events:none;
      }
      .le-land-scale-dock[hidden] { display:none!important; }
      .le-land-scale-dock > .le-land-data-card { pointer-events:auto; }
      .le-land-scale-dock .le-land-data-card {
        display:none!important; position:absolute; left:0; right:0;
        bottom:calc(100% + clamp(10px,1.6svh,18px)); width:100%;
        max-height:min(52svh,560px); box-sizing:border-box; margin:0;
        overflow:auto; overscroll-behavior:contain; pointer-events:auto; z-index:6;
      }
      .le-sfv--land.le-land-details-expanded .le-land-scale-dock .le-land-data-card { display:block!important; }
      .le-land-instrument-label {
        display:flex; align-items:center; justify-content:center; gap:7px;
        width:100%; margin:0 0 6px; color:#b7dff4;
        font-family:ui-sans-serif,system-ui,-apple-system,sans-serif;
        font-size:10px; font-weight:650; letter-spacing:.28em; line-height:1;
        text-align:center; text-transform:uppercase; text-shadow:0 0 16px rgba(65,176,235,.20);
      }
      .le-land-instrument-label::before,.le-land-instrument-label::after {
        content:""; display:block; flex:1 1 0; max-width:88px; height:1px;
        background:linear-gradient(90deg,transparent,rgba(104,190,231,.46));
      }
      .le-land-instrument-label::after { background:linear-gradient(90deg,rgba(104,190,231,.46),transparent); }
      .le-land-summary-heading {
        display:flex; flex-flow:row nowrap; justify-content:space-between; align-items:baseline;
        gap:8px; width:var(--land-content-width); min-width:0; margin:0 0 6px;
        white-space:nowrap; line-height:1;
      }
      .le-land-summary-title { min-width:0; overflow:hidden; color:#c6ddeb; font-size:clamp(9px,2.25cqi,11px); font-weight:620; letter-spacing:.055em; text-overflow:ellipsis; text-transform:uppercase; }
      .le-land-summary-range { flex:0 0 auto; color:#f7fbff; font-size:clamp(15px,4.1cqi,21px); font-weight:560; letter-spacing:-.025em; font-variant-numeric:tabular-nums; white-space:nowrap; }
      .le-land-summary-track-row { display:grid; grid-template-columns:minmax(0,1fr) var(--land-action-space); align-items:center; column-gap:var(--land-track-gap); min-width:0; }
      .le-land-sample-count { display:flex; align-items:center; justify-content:space-between; min-width:0; gap:8px; }
      .le-land-sample-count-label { color:#b9cddd; font-size:clamp(9px,1.8cqi,11px); font-weight:550; letter-spacing:.08em; text-transform:uppercase; white-space:nowrap; }
      .le-land-sample-dots { display:flex; align-items:center; justify-content:flex-end; gap:clamp(6px,1.8vw,12px); min-width:0; }
      .le-land-sample-dots span { width:5px; height:5px; flex:none; border-radius:50%; background:#8fe5ff; box-shadow:0 0 7px rgba(65,185,255,.65); }
      .le-land-scale-more {
        position:relative; flex:none; display:grid; place-items:center;
        width:var(--land-action-space); height:var(--land-action-space); margin:0; padding:0;
        justify-self:center; align-self:center; border:1px solid rgba(116,218,250,.78);
        border-radius:50%; color:#d9f7ff;
        background:radial-gradient(circle at 35% 27%,rgba(78,190,229,.18),rgba(3,19,32,.72) 72%);
        box-shadow:0 0 0 1px rgba(82,186,228,.07),0 0 13px rgba(49,177,228,.20),inset 0 1px 4px rgba(255,255,255,.10);
        font:300 22px/1 ui-sans-serif,system-ui,sans-serif; cursor:pointer;
        pointer-events:auto; touch-action:manipulation;
        transition:background .18s ease,border-color .18s ease,box-shadow .18s ease,transform .18s ease;
      }
      .le-land-scale-more:active { transform:scale(.94); }
      .le-land-scale-more:focus-visible { outline:2px solid #80d9f5; outline-offset:3px; }
      .le-land-details { margin-top:10px; border-top:1px solid rgba(165,208,235,.14); padding-top:8px; }
      .le-land-details summary { list-style:none; cursor:pointer; color:#b7d8e9; font-size:10px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; display:flex; justify-content:space-between; align-items:center; min-height:26px; }
      .le-land-details summary::-webkit-details-marker { display:none; }
      .le-land-details summary::after { content:'＋'; color:#82d9f5; font-size:15px; }
      .le-land-details[open] summary::after { content:'−'; }
      .le-sfv--land .le-sfv-metric-grid { margin-top:9px; grid-template-columns:repeat(2,minmax(0,1fr)); gap:6px; }
      .le-sfv--land .le-sfv-metric { padding:9px 10px; border-radius:11px; background:rgba(1,8,17,.42); }
      .le-sfv--land .le-sfv-metric-label { font-size:8px; margin-bottom:4px; }
      .le-sfv--land .le-sfv-metric-value { font-size:clamp(13px,3.5vw,17px); }
      .le-sfv--land .le-sfv-attribution { margin:7px 2px 0; font-size:8px; color:#8da9bc; }
      .le-land-sample-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:7px; margin-top:10px; }
      .le-land-sample-card { min-width:0; padding:9px 10px; border:1px solid rgba(142,185,207,.16); border-radius:12px; background:rgba(1,8,17,.42); }
      .le-land-sample-name { display:block; color:#a9c6d8; font-size:9px; line-height:1.3; }
      .le-land-sample-value { display:block; margin-top:4px; color:#f2fbff; font-size:clamp(15px,4vw,19px); line-height:1.1; font-weight:650; font-variant-numeric:tabular-nums; }
      .le-land-sample-coordinate { display:block; margin-top:4px; color:#8da9bc; font:8px/1.35 ui-monospace,monospace; }
      .le-land-provenance-note { margin:9px 2px 0; color:#9bb5c6; font-size:9px; line-height:1.5; }

      @media (orientation:portrait) {
        .le-land-hud-toggle { top:15svh; }
        .le-land-dataset-orb-menu { top:calc(15svh + clamp(46px,6vmin,52px) + 10px); }
      }
      @media (orientation:landscape) {
        .le-land-scene-title { top:3vh; top:3svh; }
        .le-land-hud-toggle { top:8svh; right:8vw; }
        .le-land-dataset-orb-menu { top:calc(8svh + clamp(46px,6vmin,52px) + 10px); right:8vw; }
        .le-land-scale-dock {
          left:6%; right:auto; top:50%; bottom:auto; transform:translateY(-50%);
          width:clamp(126px,12.24vw,151px); max-width:16.2vw;
          display:grid; grid-template-columns:minmax(0,1fr); grid-template-rows:auto auto auto auto;
          column-gap:0; row-gap:8px; padding:8px; border:0; border-radius:0;
          background:transparent; box-shadow:none; backdrop-filter:none; -webkit-backdrop-filter:none;
          pointer-events:auto;
        }
        .le-land-instrument-label { grid-column:1; grid-row:1; width:100%; margin:0 0 1px; font-size:9px; letter-spacing:.18em; }
        .le-land-instrument-label::before,.le-land-instrument-label::after { max-width:24px; }
        .le-land-summary-heading { grid-column:1; grid-row:2; display:flex; flex-direction:column; align-items:center; justify-content:center; width:100%; gap:6px; white-space:normal; text-align:center; }
        .le-land-summary-title { font-size:9px; text-align:center; white-space:normal; }
        .le-land-summary-range { font-size:clamp(13px,1.45vw,16px); text-align:center; }
        .le-land-summary-track-row { grid-column:1; grid-row:3; display:flex; flex-direction:column; gap:8px; }
        .le-land-sample-count { flex-direction:column; gap:8px; }
        .le-land-sample-count-label { font-size:8px; white-space:normal; text-align:center; }
        .le-land-sample-dots { display:grid; grid-template-columns:repeat(3,5px); justify-content:center; gap:7px; }
        .le-land-scale-more { grid-column:1; grid-row:4; width:34px; height:34px; justify-self:center; align-self:center; margin:1px 0 0; }
        .le-land-scale-dock .le-land-data-card { left:calc(100% + 14px); right:auto; top:50%; bottom:auto; transform:translateY(-50%); width:min(42vw,620px); max-width:calc(80vw - 200px); max-height:85svh; overflow:auto; border-radius:16px; }
      }
      @media (max-width:360px) { .le-land-sample-grid { grid-template-columns:1fr; } }
      @media (max-height:700px) {
        .le-sfv--land.le-world-engine-host .le-sfv-body { margin-top:clamp(145px,28vh,230px); }
        .le-sfv--land .le-sfv-panel { padding-bottom:calc(env(safe-area-inset-bottom) + 112px); }
      }
      @container (max-width:430px) {
        .le-land-summary-heading { gap:7px; }
        .le-land-summary-title { font-size:clamp(8.5px,2.2cqi,10px); letter-spacing:.025em; }
        .le-land-summary-range { font-size:clamp(15px,4cqi,19px); }
      }
      @container (max-width:350px) {
        .le-land-scale-dock { --land-action-space:40px; --land-track-gap:9px; }
        .le-land-summary-heading { gap:5px; margin-bottom:5px; }
        .le-land-summary-title { font-size:8px; }
        .le-land-summary-range { font-size:15px; }
        .le-land-instrument-label { font-size:9px; letter-spacing:.22em; margin-bottom:5px; }
        .le-land-sample-count-label { font-size:8px; }
      }
    `;
    document.head.appendChild(style);
  }

  function installEngineStyles() {
    if (document.getElementById('le-land-world-engine-canvas-style')) return;
    const style = document.createElement('style');
    style.id = 'le-land-world-engine-canvas-style';
    style.textContent = `
      body.le-land-fullscreen-open #scene { visibility:hidden!important; pointer-events:none!important; }
      .le-sfv--land.le-world-engine-host { position:absolute; inset:0; isolation:isolate; background:radial-gradient(ellipse at 50% 43%,#0a1b2b 0%,#030914 58%,#010308 100%); pointer-events:none; }
      .le-world-engine-host { isolation:isolate; background:radial-gradient(ellipse at 50% 42%,rgba(15,47,75,.22),rgba(2,6,13,.88) 76%); }
      .le-world-engine-canvas { position:absolute; inset:0; z-index:0; width:100%; height:100%; display:block; pointer-events:auto; touch-action:none; outline:none; -webkit-tap-highlight-color:transparent; }
      .le-world-engine-host .le-sfv-panel { z-index:1; pointer-events:none; overflow:hidden; background:transparent; backdrop-filter:none; -webkit-backdrop-filter:none; }
      .le-world-engine-host .le-sfv-head,.le-world-engine-host .le-sfv-body { pointer-events:auto; }
      .le-world-engine-host .le-sfv-body { max-height:calc(100% - 150px); overflow-y:auto; overscroll-behavior:contain; -webkit-overflow-scrolling:touch; }
      .le-world-engine-host .le-sfv-head { text-shadow:0 2px 18px rgba(0,0,0,.85); }
      .le-world-engine-host .le-sfv-card { background:rgba(4,13,24,.58); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px); }
    `;
    document.head.appendChild(style);
  }

  // Complete Atmosphere/Oceans globe transfer: adaptive frame, resize, shared
  // location marker, globe-surface drag, pinch admission and full cleanup.
  async function initializeEngineView(view, viewId) {
    if (!view?.root || !view?.panel || !viewId) throw new TypeError('A mounted world view and stable world id are required.');
    const T = await import('../vendor/three.module.js');
    const engine = await import('../EarthEngine/Core/earth-engine.js');
    const createEarthGlobe = engine.createEarthGlobe || engine.createGlobe;
    const getDefaultCameraDistance = engine.getDefaultCameraDistance;
    if (typeof getDefaultCameraDistance !== 'function') throw new Error('Earth Engine default framing API is unavailable.');
    if (typeof createEarthGlobe !== 'function') throw new Error('The reusable Earth Engine factory is unavailable.');

    const root = view.root;
    root.classList.add('le-world-engine-host');
    installEngineStyles();
    const canvas = document.createElement('canvas');
    canvas.className = 'le-world-engine-canvas';
    canvas.setAttribute('aria-label', `${viewId} independent interactive Earth globe`);
    canvas.setAttribute('role', 'img');
    root.insertBefore(canvas, root.firstChild);
    const sceneTitle = document.createElement('div');
    sceneTitle.className = 'le-land-scene-title';
    sceneTitle.setAttribute('aria-label', 'Land');
    sceneTitle.innerHTML = '<span>LAND</span><i aria-hidden="true"></i>';
    root.appendChild(sceneTitle);

    let renderer = null;
    let scene = null;
    let camera = null;
    let earthGlobe = null;
    let gestureController = null;
    let locationMarker = null;
    let locationHalo = null;
    let locationDot = null;
    let locationVector = null;
    let syncLandLocation = null;
    let disposed = false;
    let renderQueued = false;
    let resizeObserver = null;
    let defaultCameraDistance = 3.15;
    const LAND_MAX_ZOOM = 3;
    let zoomFactor = 1;
    const layers = new Map();
    const maxPixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);

    function requestRender() {
      if (disposed || renderQueued) return;
      renderQueued = true;
      requestAnimationFrame(() => {
        renderQueued = false;
        if (!disposed && renderer && scene && camera) renderer.render(scene, camera);
      });
    }

    function resize() {
      if (disposed || !renderer || !camera) return;
      const rect = root.getBoundingClientRect();
      const width = Math.max(1, Math.round(rect.width || window.innerWidth || 1));
      const height = Math.max(1, Math.round(rect.height || window.innerHeight || 1));
      renderer.setPixelRatio(maxPixelRatio);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      defaultCameraDistance = getDefaultCameraDistance({ width, height, radius: 1, fieldOfView: 38, diameterFraction: 0.71 });
      camera.position.z = defaultCameraDistance / zoomFactor;
      requestRender();
    }

    try {
      renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
      renderer.outputColorSpace = T.SRGBColorSpace;
      renderer.setClearColor(0x02050b, 0);
      scene = new T.Scene();
      scene.background = null;
      const rect = root.getBoundingClientRect();
      const width = Math.max(1, Math.round(rect.width || window.innerWidth || 1));
      const height = Math.max(1, Math.round(rect.height || window.innerHeight || 1));
      camera = new T.PerspectiveCamera(38, width / height, 0.1, 100);
      defaultCameraDistance = getDefaultCameraDistance({ width, height, radius: 1, fieldOfView: 38, diameterFraction: 0.71 });
      camera.position.set(0, 0, defaultCameraDistance);
      camera.lookAt(0, 0, 0);
      scene.add(new T.AmbientLight(0x8aa7c8, 0.28));
      const key = new T.DirectionalLight(0xffffff, 2.0);
      key.position.set(-3, 2, 4);
      scene.add(key);
      const fill = new T.DirectionalLight(0x245b9b, 0.10);
      fill.position.set(4, -2, -3);
      scene.add(fill);

      earthGlobe = await createEarthGlobe({
        THREE: T,
        radius: 1,
        textureUrl: './EarthEngine/Assets/earth-land-ocean-ice-2048.png',
        geometryDetail: 'standard',
        maxAnisotropy: renderer.capabilities.getMaxAnisotropy(),
        atmosphere: true
      });
      if (disposed) { earthGlobe.dispose(); throw new Error('The Land view closed while its Engine globe was loading.'); }
      scene.add(earthGlobe.group);

      // Shared app Location marker. Land never starts its own GPS permission flow.
      locationVector = new T.Vector3();
      locationMarker = new T.Group();
      locationMarker.name = 'liveEarthLandLocationMarker';
      locationHalo = new T.Mesh(
        new T.SphereGeometry(0.031, 16, 12),
        new T.MeshBasicMaterial({ color:0xff234d, transparent:true, opacity:0.28, depthTest:false, depthWrite:false })
      );
      locationDot = new T.Mesh(
        new T.SphereGeometry(0.014, 16, 12),
        new T.MeshBasicMaterial({ color:0xff183f, depthTest:false, depthWrite:false })
      );
      locationHalo.renderOrder = 20;
      locationDot.renderOrder = 21;
      locationMarker.add(locationHalo, locationDot);
      locationMarker.visible = false;
      earthGlobe.surface.add(locationMarker);

      syncLandLocation = () => {
        const fix = window.liveEarthGetLocationState?.() === true
          ? window.liveEarthGetLocationFix?.()
          : null;
        if (!fix || !locationMarker || !locationVector) {
          if (locationMarker) locationMarker.visible = false;
          requestRender();
          return;
        }
        const phi = fix.latitude * Math.PI / 180;
        const lambda = fix.longitude * Math.PI / 180;
        locationVector.set(
          Math.cos(phi) * Math.cos(lambda),
          Math.sin(phi),
          -Math.cos(phi) * Math.sin(lambda)
        ).normalize();
        locationHalo.position.copy(locationVector).multiplyScalar(1.006);
        locationDot.position.copy(locationVector).multiplyScalar(1.019);
        locationMarker.visible = true;
        requestRender();
      };
      window.addEventListener('live-earth-location-fix', syncLandLocation);
      window.addEventListener('live-earth-location-state', syncLandLocation);
      syncLandLocation();

      // Surface-anchored drag and two-finger pinch, transferred as one algorithm.
      gestureController = (() => {
        const raycaster = new T.Raycaster();
        const pointerNdc = new T.Vector2();
        const anchorLocal = new T.Vector3();
        const anchorWorld = new T.Vector3();
        const targetWorld = new T.Vector3();
        const sphere = new T.Sphere(new T.Vector3(0, 0, 0), 1.001);
        const deltaRotation = new T.Quaternion();
        const MIN_GLOBE_TILT = -1.15;
        const MAX_GLOBE_TILT = 1.15;
        const worldXAxis = new T.Vector3(1, 0, 0);
        const localYAxis = new T.Vector3(0, 1, 0);
        const tiltRotation = new T.Quaternion();
        const headingRotation = new T.Quaternion();
        const pointers = new Map();
        let activePointerId = null;
        let pinchStartDistance = 0;
        let pinchStartZoom = 1;
        let hasAnchor = false;

        const isEnabled = () => !disposed && root.isConnected && runtime.isActive(viewId);
        const updatePointerRay = (x, y) => {
          const bounds = canvas.getBoundingClientRect();
          if (!(bounds.width > 0 && bounds.height > 0)) return false;
          pointerNdc.set(((x - bounds.left) / bounds.width) * 2 - 1, -((y - bounds.top) / bounds.height) * 2 + 1);
          raycaster.setFromCamera(pointerNdc, camera);
          return true;
        };
        const pickSurfacePoint = (x, y, target) => {
          if (!updatePointerRay(x, y)) return false;
          const hits = raycaster.intersectObject(earthGlobe.surface, true);
          if (!hits.length) return false;
          earthGlobe.group.updateMatrixWorld(true);
          target.copy(hits[0].point);
          earthGlobe.group.worldToLocal(target);
          return target.lengthSq() > 0;
        };
        const pointerRayToSphere = (x, y, target) => {
          if (!updatePointerRay(x, y)) return false;
          const hit = raycaster.ray.intersectSphere(sphere, target);
          if (!hit) return false;
          target.normalize();
          return true;
        };
        const clampGlobeTilt = () => {
          const q = earthGlobe.group.quaternion;
          const headingHalf = Math.atan2(q.y, q.w);
          const sinHalfTilt = q.x * Math.cos(headingHalf) + q.z * Math.sin(headingHalf);
          const cosHalfTilt = Math.hypot(q.w, q.y);
          const tilt = 2 * Math.atan2(sinHalfTilt, cosHalfTilt);
          const boundedTilt = Math.max(MIN_GLOBE_TILT, Math.min(MAX_GLOBE_TILT, tilt));
          const heading = 2 * headingHalf;
          tiltRotation.setFromAxisAngle(worldXAxis, boundedTilt);
          headingRotation.setFromAxisAngle(localYAxis, heading);
          q.copy(tiltRotation).multiply(headingRotation).normalize();
        };
        const pointerDistance = () => {
          const values = [...pointers.values()];
          if (values.length < 2) return 0;
          return Math.hypot(values[0].x - values[1].x, values[0].y - values[1].y);
        };
        const setZoom = value => {
          zoomFactor = Math.max(1, Math.min(LAND_MAX_ZOOM, value));
          camera.position.z = defaultCameraDistance / zoomFactor;
          camera.lookAt(0, 0, 0);
          requestRender();
        };
        const beginAnchor = pointer => {
          hasAnchor = pickSurfacePoint(pointer.x, pointer.y, anchorLocal);
          activePointerId = hasAnchor ? pointer.id : null;
          return hasAnchor;
        };
        const onPointerDown = event => {
          if (!isEnabled()) return;
          if (event.pointerType === 'mouse' && event.button !== 0) return;
          const pointer = { id:event.pointerId, x:event.clientX, y:event.clientY };
          const startedOnGlobe = pickSurfacePoint(pointer.x, pointer.y, anchorLocal);
          if (!startedOnGlobe) return;
          pointers.set(event.pointerId, pointer);
          try { canvas.setPointerCapture(event.pointerId); } catch (_) {}
          if (pointers.size === 1) beginAnchor(pointer);
          else if (pointers.size === 2) {
            hasAnchor = false;
            activePointerId = null;
            pinchStartDistance = Math.max(1, pointerDistance());
            pinchStartZoom = zoomFactor;
          }
          event.preventDefault();
        };
        const onPointerMove = event => {
          if (!isEnabled() || !pointers.has(event.pointerId)) return;
          const pointer = pointers.get(event.pointerId);
          pointer.x = event.clientX;
          pointer.y = event.clientY;
          if (pointers.size >= 2) {
            const distance = pointerDistance();
            if (pinchStartDistance > 0) setZoom(pinchStartZoom * distance / pinchStartDistance);
            event.preventDefault();
            return;
          }
          if (pointers.size !== 1 || event.pointerId !== activePointerId || !hasAnchor) return;
          if (!pointerRayToSphere(pointer.x, pointer.y, targetWorld)) return;
          earthGlobe.group.updateMatrixWorld(true);
          anchorWorld.copy(anchorLocal).applyQuaternion(earthGlobe.group.quaternion).normalize();
          deltaRotation.setFromUnitVectors(anchorWorld, targetWorld);
          earthGlobe.group.quaternion.premultiply(deltaRotation).normalize();
          clampGlobeTilt();
          earthGlobe.group.updateMatrixWorld(true);
          requestRender();
          event.preventDefault();
        };
        const onPointerUp = event => {
          if (!pointers.has(event.pointerId)) return;
          pointers.delete(event.pointerId);
          try { if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId); } catch (_) {}
          hasAnchor = false;
          activePointerId = null;
          if (pointers.size === 1) beginAnchor([...pointers.values()][0]);
          else if (pointers.size >= 2) {
            pinchStartDistance = Math.max(1, pointerDistance());
            pinchStartZoom = zoomFactor;
          }
        };
        const onPointerCancel = event => onPointerUp(event);
        canvas.addEventListener('pointerdown', onPointerDown, { passive:false });
        canvas.addEventListener('pointermove', onPointerMove, { passive:false });
        canvas.addEventListener('pointerup', onPointerUp);
        canvas.addEventListener('pointercancel', onPointerCancel);
        canvas.addEventListener('lostpointercapture', onPointerCancel);
        return {
          dispose() {
            canvas.removeEventListener('pointerdown', onPointerDown);
            canvas.removeEventListener('pointermove', onPointerMove);
            canvas.removeEventListener('pointerup', onPointerUp);
            canvas.removeEventListener('pointercancel', onPointerCancel);
            canvas.removeEventListener('lostpointercapture', onPointerCancel);
            pointers.clear();
            hasAnchor = false;
          }
        };
      })();

      resize();
      if (typeof ResizeObserver === 'function') {
        resizeObserver = new ResizeObserver(resize);
        resizeObserver.observe(root);
      }
      window.addEventListener('resize', resize, { passive:true });
      window.addEventListener('orientationchange', resize, { passive:true });

      function attachLayer(id, factory) {
        if (disposed) throw new Error('This world globe has already been disposed.');
        if (typeof id !== 'string' || !id.trim() || typeof factory !== 'function') throw new TypeError('A layer needs an id and factory.');
        removeLayer(id);
        const cleanup = factory({ THREE:T, scene, earth:earthGlobe.surface, group:earthGlobe.group, camera, renderer, redraw:requestRender, requestRender });
        if (typeof cleanup === 'function') layers.set(id, cleanup);
        requestRender();
        return () => removeLayer(id);
      }
      function removeLayer(id) {
        const cleanup = layers.get(id);
        if (!cleanup) return false;
        layers.delete(id);
        try { cleanup(); } catch (error) { console.warn(`[LIVE // EARTH] ${viewId} layer cleanup failed:`, error); }
        requestRender();
        return true;
      }
      function dispose() {
        if (disposed) return;
        disposed = true;
        window.removeEventListener('resize', resize);
        window.removeEventListener('orientationchange', resize);
        resizeObserver?.disconnect(); resizeObserver = null;
        if (syncLandLocation) {
          window.removeEventListener('live-earth-location-fix', syncLandLocation);
          window.removeEventListener('live-earth-location-state', syncLandLocation);
        }
        gestureController?.dispose?.(); gestureController = null;
        for (const id of [...layers.keys()]) removeLayer(id);
        if (locationMarker?.parent) locationMarker.parent.remove(locationMarker);
        locationHalo?.geometry?.dispose?.(); locationHalo?.material?.dispose?.();
        locationDot?.geometry?.dispose?.(); locationDot?.material?.dispose?.();
        locationMarker = null; locationHalo = null; locationDot = null; locationVector = null;
        earthGlobe?.dispose?.(); earthGlobe = null;
        renderer?.dispose?.(); renderer?.forceContextLoss?.(); renderer = null;
        sceneTitle.remove(); canvas.remove(); scene = null; camera = null;
        root.classList.remove('le-world-engine-host');
      }
      requestRender();
      return Object.freeze({ THREE:T, scene, camera, renderer, canvas, globe:earthGlobe, earth:earthGlobe.surface, attachLayer, removeLayer, requestRender, dispose });
    } catch (error) {
      disposed = true;
      window.removeEventListener('resize', resize);
      window.removeEventListener('orientationchange', resize);
      resizeObserver?.disconnect();
      if (syncLandLocation) {
        window.removeEventListener('live-earth-location-fix', syncLandLocation);
        window.removeEventListener('live-earth-location-state', syncLandLocation);
      }
      gestureController?.dispose?.();
      if (locationMarker?.parent) locationMarker.parent.remove(locationMarker);
      locationHalo?.geometry?.dispose?.(); locationHalo?.material?.dispose?.();
      locationDot?.geometry?.dispose?.(); locationDot?.material?.dispose?.();
      earthGlobe?.dispose?.(); renderer?.dispose?.(); renderer?.forceContextLoss?.();
      sceneTitle.remove(); canvas.remove(); root.classList.remove('le-world-engine-host');
      throw error;
    }
  }

  function formatNumber(value) {
    return Number.isFinite(value)
      ? value.toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:2 })
      : '—';
  }
  function formatTime(value) {
    if (!value) return 'Time unavailable';
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? 'Time unavailable'
      : new Intl.DateTimeFormat(undefined, { dateStyle:'medium', timeStyle:'short' }).format(date);
  }

  function activateView() {
    installHudStyle();
    const view = runtime.mount(WORLD.id);
    if (!view) return () => {};
    view.root.querySelector('.le-sfv-head')?.remove();
    view.root.querySelector('.le-sfv-pill')?.remove();
    document.body.classList.add('le-land-fullscreen-open');

    const status = runtime.el('p', 'le-sfv-status', '');
    status.dataset.state = 'neutral';
    status.hidden = true;
    const showStatus = (message, state = 'neutral') => {
      status.hidden = false;
      if (!status.isConnected) view.body.appendChild(status);
      runtime.setStatus(status, message, state);
    };
    const clearStatus = () => {
      status.remove();
      status.hidden = true;
    };

    // Match the compact Atmosphere/Oceans settings orb and ten-orb menu.
    const hudToggle = runtime.el('button', 'le-land-hud-toggle');
    hudToggle.type = 'button';
    const hudIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    hudIcon.setAttribute('viewBox', '0 0 24 24');
    hudIcon.setAttribute('aria-hidden', 'true');
    hudIcon.classList.add('le-land-hud-toggle-icon');
    hudIcon.innerHTML = '<path d="M4 7h7m4 0h5M4 17h3m4 0h9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="13" cy="7" r="2" fill="#061525" stroke="currentColor" stroke-width="1.6"/><circle cx="9" cy="17" r="2" fill="#061525" stroke="currentColor" stroke-width="1.6"/>';
    hudToggle.append(hudIcon);

    const datasetOrbMenu = runtime.el('div', 'le-land-dataset-orb-menu');
    datasetOrbMenu.id = 'le-land-dataset-orb-menu';
    datasetOrbMenu.setAttribute('role', 'group');
    datasetOrbMenu.setAttribute('aria-label', 'Land datasets');
    hudToggle.setAttribute('aria-controls', datasetOrbMenu.id);
    hudToggle.setAttribute('aria-expanded', 'false');
    hudToggle.setAttribute('aria-haspopup', 'true');
    hudToggle.setAttribute('aria-label', 'Open Land datasets');
    hudToggle.addEventListener('click', () => {
      const open = datasetOrbMenu.classList.toggle('is-open');
      hudToggle.setAttribute('aria-expanded', String(open));
      hudToggle.setAttribute('aria-label', open ? 'Close Land datasets' : 'Open Land datasets');
    });
    view.root.appendChild(hudToggle);

    // The Land information instrument occupies the same floating dock as the
    // Atmosphere/Oceans colour scale. Its content remains discrete because the
    // current Land dataset contains six point samples, not a continuous raster.
    const details = runtime.card('Land observations', 'Verified regional point observations and source details.');
    details.classList.add('le-land-data-card');
    details.hidden = true;
    const summaryRange = runtime.el('div', 'le-land-summary-range', '—');
    const summaryTitle = runtime.el('div', 'le-land-summary-title', 'Land observations · sample range');
    const summaryHeading = runtime.el('div', 'le-land-summary-heading');
    summaryHeading.append(summaryTitle, summaryRange);
    const scaleDock = runtime.el('section', 'le-land-scale-dock');
    scaleDock.setAttribute('aria-label', 'Land numerical observation summary');
    scaleDock.hidden = true;
    const instrumentLabel = runtime.el('div', 'le-land-instrument-label');
    instrumentLabel.appendChild(runtime.el('span', 'le-land-instrument-name', 'Land'));
    scaleDock.append(details, instrumentLabel, summaryHeading);

    const summaryTrackRow = runtime.el('div', 'le-land-summary-track-row');
    const sampleCount = runtime.el('div', 'le-land-sample-count');
    const sampleCountLabel = runtime.el('span', 'le-land-sample-count-label', '6 regional point samples');
    const sampleDots = runtime.el('div', 'le-land-sample-dots');
    sampleDots.setAttribute('aria-label', 'Six distinct regional observations');
    for (let i = 0; i < 6; i++) sampleDots.appendChild(runtime.el('span'));
    sampleCount.append(sampleCountLabel, sampleDots);
    const scaleMore = runtime.el('button', 'le-land-scale-more', '+');
    scaleMore.type = 'button';
    scaleMore.setAttribute('aria-label', 'Show Land observations and provenance');
    scaleMore.setAttribute('aria-controls', 'le-land-data-details');
    scaleMore.setAttribute('aria-expanded', 'false');
    summaryTrackRow.append(sampleCount, scaleMore);
    scaleDock.appendChild(summaryTrackRow);
    view.root.appendChild(scaleDock);

    const sampleGrid = runtime.el('div', 'le-land-sample-grid');
    const disclosure = runtime.el('details', 'le-land-details');
    disclosure.id = 'le-land-data-details';
    disclosure.appendChild(runtime.el('summary', '', 'Data details & provenance'));
    const metric = runtime.el('div', 'le-sfv-metric-grid');
    disclosure.appendChild(metric);
    const provenance = runtime.el('p', 'le-land-provenance-note', '');
    details.append(sampleGrid, disclosure, provenance);

    const syncScaleMore = () => {
      const expanded = disclosure.open;
      scaleMore.textContent = expanded ? '−' : '+';
      scaleMore.setAttribute('aria-expanded', String(expanded));
      scaleMore.setAttribute('aria-label', expanded ? 'Collapse Land observations and provenance' : 'Expand Land observations and provenance');
      view.root.classList.toggle('le-land-details-expanded', expanded);
    };
    scaleMore.addEventListener('click', () => {
      disclosure.open = !disclosure.open;
      syncScaleMore();
    });
    disclosure.addEventListener('toggle', syncScaleMore);

    const datasetOrbButtons = new Map();
    let selectedDataset = null;
    for (const item of DATASET_OPTIONS) {
      const orb = runtime.el('button', 'le-land-dataset-orb');
      orb.type = 'button';
      orb.dataset.dataset = item.id;
      orb.setAttribute('aria-label', item.label);
      orb.setAttribute('aria-pressed', 'false');
      orb.title = `${item.label}${item.available ? ' · verified regional point samples' : ' · Source adapter not configured'}`;
      const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      icon.setAttribute('viewBox', '0 0 24 24');
      icon.setAttribute('aria-hidden', 'true');
      icon.classList.add('le-land-dataset-orb-icon');
      icon.style.color = item.color;
      icon.innerHTML = ICONS[item.icon];
      orb.appendChild(icon);
      orb.addEventListener('click', () => selectDataset(item));
      datasetOrbMenu.appendChild(orb);
      datasetOrbButtons.set(item.id, orb);
    }
    view.root.appendChild(datasetOrbMenu);

    let closed = false;
    let layerDispose = null;
    let markerRoot = null;
    let worldGlobe = null;
    let dataRequest = null;
    let engineReady = null;

    const onKeyDown = event => {
      if (event.key === 'Escape') {
        if (datasetOrbMenu.classList.contains('is-open')) {
          datasetOrbMenu.classList.remove('is-open');
          hudToggle.setAttribute('aria-expanded', 'false');
          hudToggle.setAttribute('aria-label', 'Open Land datasets');
        } else if (disclosure.open) {
          disclosure.open = false;
          syncScaleMore();
        }
      }
    };
    document.addEventListener('keydown', onKeyDown);

    function setSelectedDataset(id) {
      selectedDataset = id;
      for (const [key, orb] of datasetOrbButtons) {
        const active = key === id;
        orb.classList.toggle('is-selected', active);
        orb.setAttribute('aria-pressed', String(active));
      }
    }

    function removeActiveLayer() {
      if (typeof layerDispose === 'function') {
        const dispose = layerDispose;
        layerDispose = null;
        try { dispose(); } catch (error) { console.warn('[LIVE // EARTH] Land point layer detach failed.', error); }
      }
      try { markerRoot?.removeFromParent?.(); } catch (_) {}
      markerRoot = null;
      delete view.root.dataset.landObservations;
    }

    function makeMetric(labelText, value, unit = '') {
      const item = runtime.el('div', 'le-sfv-metric');
      item.appendChild(runtime.el('span', 'le-sfv-metric-label', labelText));
      const valueNode = runtime.el('strong', 'le-sfv-metric-value', value);
      if (unit) valueNode.appendChild(runtime.el('span', 'le-sfv-metric-unit', ` ${unit}`));
      metric.appendChild(item);
    }

    function markerColor(record, config) {
      const status = record.quality?.sample_status;
      if (config.kind === 'forest') {
        if (status === 'mapped_land' && record.value === 0) return 0x79e2ae;
        if (status === 'mapped_land' && Number.isFinite(record.value)) return 0xff986f;
        if (status === 'water') return 0x65bce8;
        return 0x8995a5;
      }
      if (config.kind === 'ndvi') {
        if (status !== 'valid' || !Number.isFinite(record.value)) return 0x8995a5;
        const value = Math.max(-0.2, Math.min(1, record.value));
        const t = (value + 0.2) / 1.2;
        const low = [224, 171, 112], high = [105, 225, 151];
        return (Math.round(low[0] + (high[0] - low[0]) * t) << 16) |
          (Math.round(low[1] + (high[1] - low[1]) * t) << 8) |
          Math.round(low[2] + (high[2] - low[2]) * t);
      }
      if (!Number.isFinite(record.value)) return 0x8995a5;
      const values = recordsForColorScale;
      const min = Math.min(...values), max = Math.max(...values);
      const t = max === min ? 0.5 : (record.value - min) / (max - min);
      const low = [83, 173, 235], high = [255, 164, 103];
      return (Math.round(low[0] + (high[0] - low[0]) * t) << 16) |
        (Math.round(low[1] + (high[1] - low[1]) * t) << 8) |
        Math.round(low[2] + (high[2] - low[2]) * t);
    }

    let recordsForColorScale = [];

    function sampleStatusLabel(record, config) {
      if (Number.isFinite(record.value)) {
        if (config.kind === 'forest') return record.value === 0 ? 'No detected loss · mapped land' : `Loss year code ${record.value}`;
        if (config.kind === 'ndvi') return `NDVI ${formatNumber(record.value)}`;
        return `${formatNumber(record.value)} ${config.displayUnit}`;
      }
      const status = record.quality?.sample_status;
      if (status === 'water') return 'Persistent water · no land value';
      if (status === 'unmapped') return 'Unmapped · no data';
      if (status === 'source_nodata') return 'Source no-data';
      return 'No data';
    }

    function renderSampleMarkers(records, config) {
      if (!worldGlobe || typeof worldGlobe.attachLayer !== 'function') throw new Error('The Earth Engine globe is not ready.');
      recordsForColorScale = records.filter(record => Number.isFinite(record.value)).map(record => record.value);
      layerDispose = worldGlobe.attachLayer(`land-${config.id}-regional-samples`, ({ THREE, earth }) => {
        if (!THREE?.Group || !earth?.add) throw new Error('The Earth Engine did not provide its Three.js globe surface.');
        markerRoot = new THREE.Group();
        markerRoot.name = `liveEarth-land-${config.id}-regional-samples`;
        const geometries = [];
        const materials = [];
        const haloGeometry = new THREE.SphereGeometry(0.022, 14, 10);
        const dotGeometry = new THREE.SphereGeometry(0.010, 16, 12);
        geometries.push(haloGeometry, dotGeometry);
        for (const record of records) {
          const color = markerColor(record, config);
          const isMissing = !Number.isFinite(record.value);
          const haloMaterial = new THREE.MeshBasicMaterial({
            color, transparent:true, opacity:isMissing ? 0.13 : 0.27,
            depthTest:true, depthWrite:false
          });
          const dotMaterial = new THREE.MeshBasicMaterial({
            color, transparent:isMissing, opacity:isMissing ? 0.68 : 1,
            depthTest:true, depthWrite:false
          });
          materials.push(haloMaterial, dotMaterial);
          const phi = record.latitude * Math.PI / 180;
          const lambda = record.longitude * Math.PI / 180;
          const direction = new THREE.Vector3(
            Math.cos(phi) * Math.cos(lambda),
            Math.sin(phi),
            -Math.cos(phi) * Math.sin(lambda)
          ).normalize();
          const halo = new THREE.Mesh(haloGeometry, haloMaterial);
          halo.position.copy(direction).multiplyScalar(1.012);
          halo.renderOrder = 14;
          const dot = new THREE.Mesh(dotGeometry, dotMaterial);
          dot.position.copy(direction).multiplyScalar(1.022);
          dot.renderOrder = 15;
          const tile = record.quality?.sample_tile_id || '';
          halo.userData.sampleTile = tile;
          dot.userData.sampleTile = tile;
          dot.userData.sampleStatus = record.quality?.sample_status || (isMissing ? 'no_data' : 'valid');
          dot.userData.sampleValue = record.value;
          markerRoot.add(halo, dot);
        }
        earth.add(markerRoot);
        return () => {
          markerRoot?.removeFromParent?.();
          geometries.forEach(geometry => geometry.dispose());
          materials.forEach(material => material.dispose());
          markerRoot = null;
        };
      });
      if (typeof layerDispose !== 'function') throw new Error('The discrete Land observation markers could not attach.');
      view.root.dataset.landObservations = `verified-${config.id}-regional-point-samples`;
      worldGlobe.requestRender?.();
    }

    function buildSampleCards(records, config) {
      sampleGrid.replaceChildren();
      for (const record of records) {
        const key = record.quality?.sample_tile_id;
        const card = runtime.el('article', 'le-land-sample-card');
        card.appendChild(runtime.el('span', 'le-land-sample-name', REGION_NAMES[key] || key || 'Regional sample'));
        card.appendChild(runtime.el('strong', 'le-land-sample-value', sampleStatusLabel(record, config)));
        card.appendChild(runtime.el('span', 'le-land-sample-coordinate', `${formatNumber(record.latitude)}°, ${formatNumber(record.longitude)}°`));
        const quality = record.quality?.quality_flag_raw;
        if (Number.isFinite(quality)) card.appendChild(runtime.el('span', 'le-land-sample-coordinate', `Source quality flag ${quality}`));
        sampleGrid.appendChild(card);
      }
    }

    function validateDatasetRecords(metadata, records, config) {
      if (metadata.dataset_id !== config.datasetId) throw new Error('Dataset identity does not match the Land registry.');
      if (metadata.format !== 'records' || metadata.data_kind !== 'point_samples') throw new Error('The selected Land field is not registered as point samples.');
      if (metadata.coverage_mode !== 'six_sparse_regional_point_samples') throw new Error('Unexpected Land sample coverage mode.');
      if (metadata.units !== config.units || metadata.source_id !== config.sourceId) throw new Error('Land source or units do not match the registered dataset.');
      if (config.parameter && metadata.parameter !== config.parameter) throw new Error('Land parameter does not match the registered NASA POWER field.');
      const valid = records.filter(record =>
        record.dataset_id === config.datasetId &&
        record.source_id === config.sourceId &&
        record.unit === config.units &&
        Number.isFinite(record.latitude) && record.latitude >= -90 && record.latitude <= 90 &&
        Number.isFinite(record.longitude) && record.longitude >= -180 && record.longitude <= 180 &&
        typeof record.observed_at === 'string' && !Number.isNaN(Date.parse(record.observed_at)) &&
        (config.kind === 'numeric'
          ? record.quality?.sample_mode === 'regional_point' && Number.isFinite(record.value)
          : config.kind === 'ndvi'
            ? record.quality?.sample_mode === 'nearest_native_grid_cell' &&
              (Number.isFinite(record.value) || record.quality?.sample_status === 'source_nodata')
            : record.quality?.sample_mode === 'regional_point' &&
              (Number.isFinite(record.value) || ['water','unmapped'].includes(record.quality?.sample_status)))
      );
      const sampleIds = valid.map(record => record.quality?.sample_tile_id);
      if (valid.length !== 6 || new Set(sampleIds).size !== 6 || metadata.record_count !== 6) {
        throw new Error(`Expected six unique regional sample locations, including source no-data states; received ${valid.length}.`);
      }
      for (const id of REGION_ORDER) {
        if (!sampleIds.includes(id)) throw new Error(`The registered ${REGION_NAMES[id]} sample is missing.`);
      }
      valid.sort((a, b) => REGION_ORDER.indexOf(a.quality.sample_tile_id) - REGION_ORDER.indexOf(b.quality.sample_tile_id));
      return valid;
    }

    async function selectDataset(item) {
      if (closed || !runtime.isActive(WORLD.id)) return;
      datasetOrbMenu.classList.remove('is-open');
      hudToggle.setAttribute('aria-expanded', 'false');
      hudToggle.setAttribute('aria-label', 'Open Land datasets');

      const config = LAND_DATASETS[item.id];
      if (!config) {
        dataRequest?.abort();
        dataRequest = null;
        removeActiveLayer();
        setSelectedDataset(item.id);
        details.hidden = true;
        scaleDock.hidden = true;
        disclosure.open = false;
        syncScaleMore();
        showStatus(`${item.label} is registered in the Land catalogue, but its source adapter has not been configured. The clean Earth globe remains interactive.`, 'neutral');
        worldGlobe?.requestRender?.();
        return;
      }

      if (selectedDataset === item.id && layerDispose) {
        dataRequest?.abort();
        dataRequest = null;
        removeActiveLayer();
        setSelectedDataset(null);
        details.hidden = true;
        scaleDock.hidden = true;
        disclosure.open = false;
        syncScaleMore();
        clearStatus();
        worldGlobe?.requestRender?.();
        return;
      }

      dataRequest?.abort();
      dataRequest = null;
      removeActiveLayer();
      scaleDock.hidden = true;
      details.hidden = true;
      disclosure.open = false;
      syncScaleMore();
      setSelectedDataset(item.id);
      summaryTitle.textContent = `${config.label} · regional samples`;
      const controller = new AbortController();
      dataRequest = controller;
      const button = datasetOrbButtons.get(item.id);
      if (button) button.disabled = true;
      showStatus(`Loading and verifying ${config.sourceLabel} regional point samples…`, 'neutral');

      try {
        if (engineReady) await engineReady;
        if (closed || controller.signal.aborted || !runtime.isActive(WORLD.id)) return;
        const base = `${VALUES_BASE_URL}${config.datasetId}/`;
        const [metadataResponse, recordsResponse] = await Promise.all([
          fetch(`${base}metadata.json`, { cache:'no-store', signal:controller.signal }),
          fetch(`${base}records.jsonl`, { cache:'no-store', signal:controller.signal })
        ]);
        if (!metadataResponse.ok || !recordsResponse.ok) {
          throw new Error(`Stored Land dataset request failed (${metadataResponse.status}/${recordsResponse.status}).`);
        }
        const metadata = await metadataResponse.json();
        const recordsText = await recordsResponse.text();
        const records = recordsText.split(/\r?\n/).filter(Boolean).map(line => JSON.parse(line));
        if (closed || controller.signal.aborted || !runtime.isActive(WORLD.id)) return;

        const samples = validateDatasetRecords(metadata, records, config);
        const numeric = samples.filter(record => Number.isFinite(record.value));
        if (!numeric.length) throw new Error('This dataset currently contains no numeric samples to plot.');
        const observedTimes = samples.map(record => Date.parse(record.observed_at));
        const latestObserved = new Date(Math.max(...observedTimes)).toISOString();
        const min = Math.min(...numeric.map(record => record.value));
        const max = Math.max(...numeric.map(record => record.value));
        const updated = metadata.updated_at_utc || samples.map(record => record.retrieved_at).filter(Boolean).sort().at(-1);
        const observedLabel = formatTime(latestObserved);
        const updatedLabel = formatTime(updated);
        const validCount = numeric.length;
        const missingCount = samples.length - validCount;

        if (closed || controller.signal.aborted || !runtime.isActive(WORLD.id)) return;
        renderSampleMarkers(samples, config);
        buildSampleCards(samples, config);
        details.querySelector('h2').textContent = config.label;
        const subtitle = details.querySelector('p');
        if (subtitle) subtitle.textContent = `${config.sourceLabel} · ${samples.length} regional locations`;
        summaryRange.textContent = config.kind === 'forest'
          ? `${validCount} mapped land samples`
          : `${formatNumber(min)}–${formatNumber(max)} ${config.displayUnit}`;
        sampleCountLabel.textContent = `${validCount} numeric · ${missingCount} no-data`;
        details.hidden = false;
        scaleDock.hidden = false;
        metric.replaceChildren();
        makeMetric('Regional locations', String(samples.length));
        makeMetric('Numeric samples', String(validCount));
        makeMetric('No-data samples', String(missingCount));
        makeMetric('Observed / valid time', observedLabel);
        makeMetric('Snapshot updated', updatedLabel);
        makeMetric('Sample range', config.kind === 'forest'
          ? 'No detected loss at mapped samples'
          : `${formatNumber(min)} to ${formatNumber(max)} ${config.displayUnit}`);
        makeMetric('Source', config.sourceLabel);
        const period = metadata.source_observation_period ? ` Observation period: ${metadata.source_observation_period}.` : '';
        const warning = config.kind === 'ndvi'
          ? ' NDVI represents vegetation greenness/activity, not a direct plant-health diagnosis.'
          : config.kind === 'forest'
            ? ' These are six point samples, not a global forest-loss raster or area estimate. Water and unmapped pixels are not treated as zero loss.'
            : ' No continuous global field, raster, or interpolation is shown.';
        const sourceUrl = samples.find(record => record.provenance?.source_url)?.provenance?.source_url || metadata.source_url;
        provenance.replaceChildren();
        provenance.appendChild(document.createTextNode(
          `Observed ${observedLabel}. Updated ${updatedLabel}.${period}${warning} Source: ${metadata.source_name || config.sourceLabel}. `
        ));
        if (typeof sourceUrl === 'string') {
          try {
            const url = new URL(sourceUrl);
            const allowedHosts = ['power.larc.nasa.gov','www.ncei.noaa.gov','storage.googleapis.com'];
            if (url.protocol === 'https:' && allowedHosts.includes(url.hostname)) {
              const link = runtime.el('a', '', 'Open source data');
              link.href = url.href;
              link.target = '_blank';
              link.rel = 'noopener noreferrer';
              link.style.color = '#8edcff';
              provenance.appendChild(link);
            }
          } catch (_) {}
        }
        view.root.dataset.landDataset = config.datasetId;
        clearStatus();
        worldGlobe?.requestRender?.();
      } catch (error) {
        if (!closed && !controller.signal.aborted && runtime.isActive(WORLD.id)) {
          removeActiveLayer();
          setSelectedDataset(null);
          details.hidden = true;
          scaleDock.hidden = true;
          showStatus(`${config.label} data could not be displayed. The base Earth globe remains active. ${error?.message || ''}`, 'error');
        }
      } finally {
        if (dataRequest === controller) {
          dataRequest = null;
          if (button) button.disabled = false;
        }
      }
    }

    const cleanup = () => {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKeyDown);
      document.body.classList.remove('le-land-fullscreen-open');
      dataRequest?.abort();
      dataRequest = null;
      hudToggle.remove();
      datasetOrbMenu.remove();
      scaleDock.remove();
      status.remove();
      removeActiveLayer();
      try { worldGlobe?.dispose?.(); } catch (error) { console.warn('[LIVE // EARTH] Land Engine globe cleanup failed.', error); }
      worldGlobe = null;
      delete view.root.dataset.landDataset;
      delete view.root.dataset.landObservations;
      delete view.root.dataset.globeEngine;
      view.root.classList.remove('le-land-details-expanded');
    };

    // Start the base globe immediately. Dataset requests remain user initiated.
    engineReady = (async () => {
      try {
        const globe = await initializeEngineView(view, WORLD.id);
        if (closed || !runtime.isActive(WORLD.id)) {
          globe?.dispose?.();
          return null;
        }
        if (!globe || typeof globe.attachLayer !== 'function') throw new Error('The Earth Engine globe could not be created.');
        worldGlobe = globe;
        view.root.dataset.globeEngine = 'ready';
        globe.requestRender?.();
        return globe;
      } catch (error) {
        if (!closed && runtime.isActive(WORLD.id)) showStatus(`The Earth Engine globe could not open. ${error?.message || ''}`, 'error');
        throw error;
      }
    })();
    engineReady.catch(() => {});

    return cleanup;
  }

  if (runtime.registerFeature(WORLD.id, activateView, false)) {
    window[flag] = true;
    window.dispatchEvent(new CustomEvent('live-earth-world-controller-ready', { detail:{ id:WORLD.id } }));
  }
})();
