# LIVE // EARTH — Atmosphere Glass Orb Controls

This patch updates only the Atmosphere view controller.

- Adds distinct luminous glass-orb treatments for Temperature, Pressure, Wind, and Moisture.
- Improves selected, hover, active, keyboard-focus, and reduced-motion states.
- Keeps NOAA loading, grid validation, GPU rendering, wind vectors, Earth Engine, gestures, and cleanup logic unchanged.
- Adds accessible labels to the dataset controls.

Upload the ZIP to the repository root using the existing ZIP extractor. The manifest is at the ZIP root and paths are repository-relative.
