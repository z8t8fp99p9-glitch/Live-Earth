# LIVE // EARTH — Weather Live Art injection fix

This package fixes the Home HTML injection guard in `Weather/Art/service-worker-extension.js`.

The previous guard searched for the renderer filename anywhere in the HTML. The controller bootstrap already contains that filename in its asset list, so the extension incorrectly assumed the renderer script tag was present and skipped injection.

The replacement checks for an actual `<script src="...live-art-online.js">` element instead.

## Upload

1. Upload/extract this ZIP into the repository root, preserving the `Weather/Art/` path.
2. The existing root `sw.js` import remains unchanged:
   `importScripts("./Weather/Art/service-worker-extension.js");`
3. Do not replace `sw.js`, `Weather/weather-view.js`, the art catalogue, or the tea artwork for this fix.

## Expected test

Open Weather with internet available and select RAIN. The Live Art title should become **A Rainy Tea Afternoon** and the artwork should progressively paint. The Weather layout, 10:7 card, main Weather painter, Home/Earth view, and Orb dock are not intentionally changed.

This package fixes the identified injection guard. On-device rendering still needs to be verified after the extractor commit and service-worker update.
