/* LIVE // EARTH — Weather: immersive Japanese house + responsive living weather.
   Replaces the previous Weather renderer only. Keeps the Stacks feature contract,
   scene selector, Open-Meteo source, location permission boundary and shared dock. */
(() => {
  'use strict';

  const runtime = window.LiveEarthStacksFeatureRuntime;
  if (!runtime || typeof runtime.registerFeature !== 'function') {
    console.error('[LIVE // EARTH] Weather feature runtime is unavailable.');
    return;
  }
  const { mount, isActive, globe } = runtime;
  const API = 'https://api.open-meteo.com/v1/forecast';
  const REFRESH_MS = 15 * 60 * 1000;
  const STYLE_ID = 'le-weather-house-style';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const num = v => v == null || v === '' || !Number.isFinite(Number(v)) ? null : Number(v);
  const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches === true;

  const PALETTES = {
    clear:  { sky:['#4d8298','#b7c8b7','#e4c49a'], far:'#657d82', near:'#344f4c', water:'#365e69', shade:.00, window:'#f4bd65', glow:.24 },
    cloudy: { sky:['#536b79','#9aa9a2','#c3bba8'], far:'#596d70', near:'#2e4747', water:'#304e5a', shade:.12, window:'#ffc979', glow:.48 },
    rain:   { sky:['#263e50','#607b82','#899b94'], far:'#455d63', near:'#203d3e', water:'#203f50', shade:.27, window:'#ffb95f', glow:.95 },
    storm:  { sky:['#14283d','#3b5663','#647b7d'], far:'#354b55', near:'#192f36', water:'#142f42', shade:.48, window:'#ffc06a', glow:1.25 },
    snow:   { sky:['#66899a','#b8ced0','#e4e9df'], far:'#91a9a7', near:'#4c6661', water:'#547581', shade:.04, window:'#ffc46e', glow:.92 },
    fog:    { sky:['#819b9b','#bdc9bd','#d8d8c9'], far:'#839995', near:'#526e69', water:'#58767b', shade:.10, window:'#ffd18a', glow:.72 },
    wind:   { sky:['#47788e','#a7c3bd','#e4d1ae'], far:'#5a7777', near:'#294b48', water:'#2d5663', shade:.02, window:'#f6c879', glow:.32 },
    hot:    { sky:['#5b94a5','#c4c6a8','#f0d3a0'], far:'#8b8c70', near:'#4e5942', water:'#4b7472', shade:.00, window:'#f5c77e', glow:.18 },
    night:  { sky:['#071629','#172d42','#30485a'], far:'#263b4b', near:'#142d34', water:'#102b3b', shade:.54, window:'#ffbd58', glow:1.55 }
  };

  function styles() {
    document.getElementById(STYLE_ID)?.remove();
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
      .le-sfv--weather{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;max-width:none!important;overflow:hidden!important;padding:0!important;margin:0!important;border:0!important;border-radius:0!important;background:#132b3b!important;isolation:isolate;pointer-events:none}
      .le-sfv--weather>.le-sfv-panel{display:none!important}
      .le-weather-house{position:absolute;inset:0;overflow:hidden;background:#152e40;color:#fff9ed;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;isolation:isolate;contain:layout paint style;pointer-events:auto}
      .le-weather-house canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
      .le-weather-house:after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(4,17,29,.35),transparent 25%,transparent 68%,rgba(4,17,28,.48))}
      .le-wh-ui{position:absolute;z-index:2;inset:0;display:flex;flex-direction:column;justify-content:space-between;padding:calc(env(safe-area-inset-top) + 22px) clamp(20px,5vw,54px) calc(env(safe-area-inset-bottom) + var(--le-weather-dock-clearance,140px));pointer-events:none}
      .le-wh-head{max-width:min(78%,480px);text-shadow:0 2px 22px rgba(5,17,28,.45)}
      .le-wh-brand{font-size:9px;font-weight:750;letter-spacing:.24em;color:#f5e9d4;opacity:.86}
      .le-wh-place{margin-top:12px;font-size:10px;font-weight:700;letter-spacing:.17em;text-transform:uppercase}
      .le-wh-date{margin-top:5px;font-size:11px;opacity:.75}
      .le-wh-reading{display:flex;align-items:flex-start;gap:5px;margin-top:clamp(15px,3vh,28px)}
      .le-wh-temp{font-size:clamp(70px,18vw,110px);font-weight:230;line-height:.82;letter-spacing:-.085em;font-variant-numeric:tabular-nums}
      .le-wh-degree{font-size:clamp(24px,4vw,38px);font-weight:300;margin:3px 0 0}
      .le-wh-condition{margin-top:12px;font-size:clamp(21px,4.7vw,33px);font-weight:420;letter-spacing:-.04em;line-height:1.06}
      .le-wh-feels{margin-top:7px;font-size:12px;opacity:.8}
      .le-wh-bottom{width:min(100%,680px);pointer-events:auto;text-shadow:0 2px 18px rgba(5,17,28,.5)}
      .le-wh-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;padding-top:12px;border-top:1px solid rgba(255,248,232,.42)}
      .le-wh-label{font-size:8px;font-weight:750;letter-spacing:.15em;text-transform:uppercase;opacity:.72}
      .le-wh-value{margin-top:6px;font-size:clamp(12px,2.2vw,16px);font-weight:550;white-space:nowrap}
      .le-wh-footer{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:12px;font-size:9px;letter-spacing:.05em;opacity:.78}
      .le-wh-status{max-width:66%;line-height:1.4}
      .le-wh-scene{display:flex;align-items:center;gap:7px}
      .le-wh-scene label{font-size:8px;font-weight:750;letter-spacing:.14em}
      .le-wh-scene select{max-width:112px;border:1px solid rgba(255,248,232,.45);border-radius:999px;background:rgba(8,26,40,.64);color:#fff9ed;padding:7px 9px;font:inherit;font-size:10px;outline:none;color-scheme:dark}
      .le-wh-scene select:focus-visible{outline:2px solid #fff9ed;outline-offset:3px}
      @media(orientation:portrait){.le-wh-ui{padding-left:clamp(18px,5.5vw,30px);padding-right:clamp(18px,5.5vw,30px)}.le-wh-bottom{margin-top:auto}.le-wh-head{max-width:75%}}
      @media(orientation:landscape){.le-wh-ui{padding:calc(env(safe-area-inset-top) + 12px) calc(env(safe-area-inset-right) + 20px) calc(env(safe-area-inset-bottom) + var(--le-weather-dock-clearance,110px)) calc(env(safe-area-inset-left) + 20px)}.le-wh-head{max-width:30%;width:250px}.le-wh-temp{font-size:clamp(54px,9vw,82px)}.le-wh-condition{font-size:clamp(19px,3vw,26px);margin-top:8px}.le-wh-bottom{align-self:flex-start;width:250px;max-width:30%}.le-wh-metrics{grid-template-columns:repeat(2,minmax(0,1fr));row-gap:8px}.le-wh-footer{align-items:flex-start;flex-direction:column}}
      @media(max-height:440px) and (orientation:landscape){.le-wh-ui{padding-top:calc(env(safe-area-inset-top) + 6px)}.le-wh-brand{font-size:8px}.le-wh-reading{margin-top:7px}.le-wh-temp{font-size:52px}.le-wh-condition{font-size:18px}.le-wh-metrics{padding-top:7px;gap:5px 10px}.le-wh-footer{margin-top:6px}}
    `;
    document.head.appendChild(s);
  }

  function screenElement() {
    const el = document.createElement('main');
    el.className = 'le-weather-house';
    el.setAttribute('aria-label','Japanese mountain house with live weather');
    el.innerHTML = `
      <canvas aria-hidden="true"></canvas>
      <div class="le-wh-ui">
        <header class="le-wh-head">
          <div class="le-wh-brand">LIVE // EARTH · WEATHER</div>
          <div class="le-wh-place" data-wx="place">SCENE PREVIEW</div>
          <div class="le-wh-date" data-wx="date">—</div>
          <div class="le-wh-reading"><span class="le-wh-temp" data-wx="temp">20</span><span class="le-wh-degree">°</span></div>
          <div class="le-wh-condition" data-wx="condition">Clear sky</div>
          <div class="le-wh-feels" data-wx="feels">Feels like 19°</div>
        </header>
        <footer class="le-wh-bottom">
          <div class="le-wh-metrics">
            <div><div class="le-wh-label">Today</div><div class="le-wh-value" data-wx="range">— / —</div></div>
            <div><div class="le-wh-label">Rain chance</div><div class="le-wh-value" data-wx="rain">—</div></div>
            <div><div class="le-wh-label">Wind</div><div class="le-wh-value" data-wx="wind">—</div></div>
            <div><div class="le-wh-label">Humidity</div><div class="le-wh-value" data-wx="humidity">—</div></div>
          </div>
          <div class="le-wh-footer">
            <div class="le-wh-status" data-wx="status" role="status" aria-live="polite">Location is off · sample values</div>
            <div class="le-wh-scene"><label for="le-wx-scene-select">SCENE</label><select id="le-wx-scene-select" aria-label="Preview weather scene">
              <option value="auto">AUTO</option><option value="clear">CLEAR</option><option value="cloudy">CLOUDY</option><option value="rain">RAIN</option><option value="storm">STORM</option><option value="snow">SNOW</option><option value="fog">FOG</option><option value="wind">WIND</option><option value="hot">HEAT</option><option value="night">NIGHT</option>
            </select></div>
          </div>
        </footer>
      </div>`;
    return el;
  }

  const setText = (root,key,value) => { const n=root.querySelector(`[data-wx="${key}"]`); if(n)n.textContent=value; };
  const compass = deg => { const d=num(deg); return d===null?'—':['N','NE','E','SE','S','SW','W','NW'][Math.round((((d%360)+360)%360)/45)%8]; };
  const formatDate = value => { const d=value?new Date(value):new Date(); return Number.isNaN(d.getTime())?'—':d.toLocaleString(undefined,{weekday:'long',month:'long',day:'numeric',hour:'numeric',minute:'2-digit'}); };

  function kindFor(code,current) {
    const wind=num(current.wind_speed_10m)||0, temp=num(current.temperature_2m);
    if(code===0&&temp!==null&&temp>=34)return 'hot';
    if([95,96,99].includes(code))return 'storm';
    if([71,73,75,77,85,86].includes(code))return 'snow';
    if([45,48].includes(code))return 'fog';
    if([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code))return 'rain';
    if([2,3].includes(code))return 'cloudy';
    if(wind>=34&&code<=1)return 'wind';
    return 'clear';
  }
  const LABELS={0:'Clear sky',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Freezing fog',51:'Light drizzle',53:'Drizzle',55:'Dense drizzle',56:'Freezing drizzle',57:'Freezing drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',66:'Freezing rain',67:'Heavy freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',80:'Rain showers',81:'Showers',82:'Heavy showers',85:'Snow showers',86:'Heavy snow showers',95:'Thunderstorm',96:'Thunderstorm · hail',99:'Severe thunderstorm'};
  function sample(kind) {
    const values={clear:[0,27,27,5,18,42],cloudy:[3,22,22,28,12,68],rain:[63,19,20,85,18,72],storm:[95,22,23,95,32,84],snow:[73,-2,-5,65,11,78],fog:[45,13,12,10,4,92],wind:[1,20,19,5,42,49],hot:[0,37,40,5,13,25],night:[0,17,16,3,5,58]};
    const v=values[kind]||values.clear,now=new Date();
    return {current:{time:now.toISOString().slice(0,16),temperature_2m:v[1],apparent_temperature:v[2],is_day:kind==='night'?0:1,weather_code:v[0],cloud_cover:v[3],wind_speed_10m:v[4],wind_direction_10m:245,relative_humidity_2m:v[5]},daily:{temperature_2m_max:[v[1]+3],temperature_2m_min:[v[1]-4],precipitation_probability_max:[v[3]]}};
  }
  function parse(data) {
    const c=data?.current||{},code=num(c.weather_code);
    if(code===null)throw new Error('Weather data unavailable');
    const isDay=num(c.is_day)===null?true:Number(c.is_day)===1;
    let weather=kindFor(code,c);
    if(!isDay&&weather==='clear')weather='night';
    const hour=Number(String(c.time||'').slice(11,13));
    const phase=!isDay?'night':hour<7?'dawn':hour>=17?'dusk':'day';
    return {weather,phase,code,current:c,daily:data.daily||{},cloud:num(c.cloud_cover)||0,wind:num(c.wind_speed_10m)||0};
  }

  function createRenderer(canvas) {
    const ctx=canvas.getContext('2d',{alpha:false,desynchronized:true});
    if(!ctx)throw new Error('Canvas unavailable');
    let w=1,h=1,dpr=1,raf=0,last=0,time=0,stopped=false,visible=!document.hidden;
    let state=parse(sample('clear')),drops=[],flakes=[],leaves=[],stars=[],mist=[];
    const reduced=reducedMotion();
    let seed=192837; const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
    const point=(x,y)=>({x:w*x,y:h*y});
    function resize(){
      const r=canvas.getBoundingClientRect();w=Math.max(1,r.width);h=Math.max(1,r.height);dpr=Math.min(1.7,devicePixelRatio||1);
      canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
      drops=Array.from({length:clamp(Math.round(w*h/3600),60,260)},()=>({x:rnd()*w,y:rnd()*h,v:300+rnd()*500,l:8+rnd()*18}));
      flakes=Array.from({length:clamp(Math.round(w*h/8500),28,120)},()=>({x:rnd()*w,y:rnd()*h,v:8+rnd()*28,r:1+rnd()*2.4,p:rnd()*6.28}));
      leaves=Array.from({length:clamp(Math.round(w*h/17000),20,65)},()=>({x:rnd()*w,y:rnd()*h*.8,p:rnd()*6.28,s:3+rnd()*4}));
      stars=Array.from({length:90},()=>({x:rnd()*w,y:rnd()*h*.55,r:.5+rnd()*1.2,p:rnd()*6.28}));
      mist=Array.from({length:6},(_,i)=>({x:rnd()*w,y:h*(.52+i*.045),s:.5+rnd(),a:.04+rnd()*.045}));
      draw(0);
    }
    function polygon(points,fill,stroke=null,line=1){
      ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=line;ctx.stroke();}
    }
    function mountain(y,amp,phase,fill){
      ctx.beginPath();ctx.moveTo(0,h);for(let x=0;x<=w+8;x+=Math.max(8,w/55)){const yy=y+Math.sin(x/w*6+phase)*amp+Math.sin(x/w*13+phase*2)*amp*.24;ctx.lineTo(x,yy);}ctx.lineTo(w,h);ctx.closePath();ctx.fillStyle=fill;ctx.fill();
    }
    function tree(x,base,size,sway,colour){
      ctx.save();ctx.translate(x,base);ctx.rotate(sway);
      ctx.fillStyle='#332f2a';ctx.fillRect(-size*.035,-size*.58,size*.07,size*.58);
      for(let i=0;i<4;i++){const yy=-size*(.95-i*.16),half=size*(.25-i*.035);polygon([[0,yy-size*.27],[-half,yy+size*.16],[half,yy+size*.16]],colour);}
      ctx.restore();
    }
    function house(p, palette, t){
      const x=p.x,y=p.y,s=p.s,glow=palette.glow;
      // Warm spill reaches the stone path and garden, not the whole image.
      const halo=ctx.createRadialGradient(x,y+s*.10,2,x,y+s*.10,s*1.12);
      halo.addColorStop(0,`rgba(255,181,86,${.10*glow})`);halo.addColorStop(1,'rgba(255,181,86,0)');
      ctx.fillStyle=halo;ctx.fillRect(x-s*1.5,y-s*.5,s*3,s*1.8);
      // Main timber body and raised veranda.
      polygon([[x-s*.62,y],[x+s*.62,y],[x+s*.58,y+s*.54],[x-s*.58,y+s*.54]],'#493b32');
      ctx.fillStyle='#80624a';ctx.fillRect(x-s*.72,y+s*.46,s*1.44,s*.09);
      ctx.fillStyle='#352c28';ctx.fillRect(x-s*.54,y+s*.12,s*1.08,s*.34);
      // Paper-screen windows: the glow is deliberately localized inside each shoji.
      const windowAlpha=clamp(.26+glow*.52,.25,.94);
      for(const side of [-1,1]){
        const wx=x+side*s*.29;
        ctx.save();ctx.shadowColor=palette.window;ctx.shadowBlur=s*(.05+glow*.12);
        ctx.fillStyle=`rgba(255,205,132,${windowAlpha})`;ctx.fillRect(wx-s*.105,y+s*.16,s*.21,s*.245);
        ctx.strokeStyle='rgba(74,49,34,.92)';ctx.lineWidth=Math.max(1,s*.018);
        ctx.strokeRect(wx-s*.105,y+s*.16,s*.21,s*.245);
        ctx.beginPath();ctx.moveTo(wx,y+s*.16);ctx.lineTo(wx,y+s*.405);ctx.moveTo(wx-s*.105,y+s*.282);ctx.lineTo(wx+s*.105,y+s*.282);ctx.stroke();
        ctx.restore();
      }
      // Central doorway and inner lantern.
      ctx.fillStyle='#241f20';ctx.fillRect(x-s*.105,y+s*.12,s*.21,s*.42);
      ctx.save();ctx.shadowColor='#ffc36c';ctx.shadowBlur=s*.18;ctx.fillStyle=`rgba(255,194,102,${.3+glow*.55})`;ctx.fillRect(x-s*.032,y+s*.25,s*.064,s*.12);ctx.restore();
      // Layered Japanese roof with long eaves and lifted corners.
      polygon([[x-s*.94,y+s*.04],[x-s*.62,y-s*.37],[x,y-s*.55],[x+s*.62,y-s*.37],[x+s*.94,y+s*.04],[x+s*.80,y+s*.015],[x+s*.58,y-s*.17],[x,y-s*.34],[x-s*.58,y-s*.17],[x-s*.80,y+s*.015]],'#302e30','#171f25',Math.max(1,s*.025));
      ctx.strokeStyle='#8a6a4d';ctx.lineWidth=s*.035;ctx.beginPath();ctx.moveTo(x-s*.9,y+s*.035);ctx.quadraticCurveTo(x,y-s*.13,x+s*.9,y+s*.035);ctx.stroke();
      // Small hanging entry lantern.
      ctx.save();ctx.shadowColor='#ffb955';ctx.shadowBlur=s*.2;ctx.fillStyle=`rgba(255,190,99,${.35+glow*.55})`;ctx.fillRect(x+s*.69,y+s*.13,s*.085,s*.14);ctx.restore();
      ctx.fillStyle='#292728';ctx.fillRect(x+s*.725,y+s*.10,s*.015,s*.035);ctx.fillRect(x+s*.725,y+s*.27,s*.015,s*.035);
      // Steps and a garden path.
      polygon([[x-s*.24,y+s*.54],[x+s*.24,y+s*.54],[x+s*.36,y+s*.72],[x-s*.36,y+s*.72]],'#7b7464');
      ctx.strokeStyle=`rgba(255,190,112,${.08+glow*.13})`;ctx.lineWidth=s*.055;ctx.beginPath();ctx.moveTo(x,y+s*.66);ctx.lineTo(x,y+s*1.42);ctx.stroke();
      // Roof rain/snow response.
      if(state.weather==='snow'){ctx.strokeStyle='rgba(247,250,245,.88)';ctx.lineWidth=s*.045;ctx.beginPath();ctx.moveTo(x-s*.77,y-s*.02);ctx.quadraticCurveTo(x,y-s*.42,x+s*.77,y-s*.02);ctx.stroke();}
      if(state.weather==='rain'||state.weather==='storm'){ctx.strokeStyle='rgba(160,203,212,.52)';ctx.lineWidth=Math.max(1,s*.012);ctx.beginPath();ctx.moveTo(x-s*.88,y+s*.03);ctx.lineTo(x-s*.94,y+s*.16);ctx.moveTo(x+s*.88,y+s*.03);ctx.lineTo(x+s*.94,y+s*.16);ctx.stroke();}
    }
    function drawWorld(dt){
      const p=PALETTES[state.weather]||PALETTES.clear;
      const phaseNight=state.phase==='night'||state.weather==='night';
      const sky=phaseNight?PALETTES.night.sky:p.sky;
      const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,sky[0]);g.addColorStop(.57,sky[1]);g.addColorStop(1,sky[2]);ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
      if(phaseNight){
        for(const s of stars){ctx.globalAlpha=.25+.45*Math.sin(time*.7+s.p);ctx.fillStyle='#fff5d7';ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();}
        ctx.globalAlpha=1;const mx=w*.77,my=h*.17,mr=Math.min(w,h)*.032;const halo=ctx.createRadialGradient(mx,my,mr,mx,my,mr*5);halo.addColorStop(0,'rgba(214,230,239,.22)');halo.addColorStop(1,'rgba(214,230,239,0)');ctx.fillStyle=halo;ctx.fillRect(mx-mr*5,my-mr*5,mr*10,mr*10);ctx.fillStyle='#e4e8e2';ctx.beginPath();ctx.arc(mx,my,mr,0,Math.PI*2);ctx.fill();
      }
      // Distant ridge, snow-capped peaks and nearer forested valley.
      mountain(h*.43,h*.10,.2,p.far);mountain(h*.52,h*.075,2.4,p.near);
      if(state.weather==='snow'){polygon([[w*.13,h*.40],[w*.22,h*.29],[w*.29,h*.39],[w*.24,h*.37],[w*.22,h*.33],[w*.19,h*.38]],'rgba(242,248,244,.82)');polygon([[w*.67,h*.39],[w*.78,h*.27],[w*.89,h*.41],[w*.82,h*.37],[w*.78,h*.32],[w*.74,h*.38]],'rgba(242,248,244,.78)');}
      // Water and its reflected house light.
      const waterY=h*.69;const wg=ctx.createLinearGradient(0,waterY,0,h);wg.addColorStop(0,p.water);wg.addColorStop(1,'#102a39');ctx.fillStyle=wg;ctx.fillRect(0,waterY,w,h-waterY);
      for(let i=0;i<22;i++){const yy=waterY+(i/22)*(h-waterY),alpha=.05+(i%4)*.018;ctx.strokeStyle=`rgba(215,230,220,${alpha})`;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(w*.12+Math.sin(time*.4+i)*8,yy);ctx.lineTo(w*.88+Math.sin(time*.4+i)*8,yy);ctx.stroke();}
      // The house sits on the far shore, visually dominant and clear of the information.
      const houseSize=Math.min(w,h)*(w>h?.36:.43);
      const hx=w*(w>h?.66:.54),hy=h*.625;
      // A thin warm reflection falls from the lit house into the water.
      ctx.save();ctx.globalCompositeOperation='screen';const rg=ctx.createLinearGradient(hx,waterY,hx,h);rg.addColorStop(0,`rgba(255,184,99,${.12*p.glow})`);rg.addColorStop(1,'rgba(255,184,99,0)');ctx.fillStyle=rg;ctx.fillRect(hx-houseSize*.22,waterY-houseSize*.04,houseSize*.44,h-waterY+houseSize*.04);ctx.restore();
      // Foreground shore and framing pines.
      polygon([[0,h*.72],[w*.18,h*.66],[w*.38,h*.73],[w*.57,h*.68],[w*.76,h*.73],[w,h*.67],[w,h],[0,h]],'#1c3536');
      tree(w*.07,h*.76,Math.min(w,h)*.27,Math.sin(time*.6)*.018,'#173b39');
      tree(w*.93,h*.77,Math.min(w,h)*.29,Math.sin(time*.6+1)*.025,'#193e3b');
      tree(w*.16,h*.70,Math.min(w,h)*.17,Math.sin(time*.6+2)*.02,'#244941');
      tree(w*.86,h*.70,Math.min(w,h)*.18,Math.sin(time*.6+3)*.02,'#244941');
      // House light softly catches nearby ground, while the rest of the image remains natural.
      if(p.glow>.4){const l=ctx.createRadialGradient(hx,hy+houseSize*.4,2,hx,hy+houseSize*.4,houseSize*1.6);l.addColorStop(0,`rgba(255,183,99,${.10*p.glow})`);l.addColorStop(1,'rgba(255,183,99,0)');ctx.fillStyle=l;ctx.fillRect(hx-houseSize*1.6,hy-houseSize,houseSize*3.2,houseSize*2.2);}
      // Weather-specific moving atmosphere.
      if(state.weather==='rain'||state.weather==='storm'){
        ctx.strokeStyle=state.weather==='storm'?'rgba(205,225,232,.42)':'rgba(211,231,234,.34)';ctx.lineWidth=1;ctx.lineCap='round';
        for(const d of drops){d.y+=d.v*dt;d.x-=d.v*.11*dt;if(d.y>h+20){d.y=-20;d.x=rnd()*w;}if(d.x<0)d.x=w;ctx.beginPath();ctx.moveTo(d.x,d.y);ctx.lineTo(d.x-3,d.y+10);ctx.stroke();}
      } else if(state.weather==='snow'){
        ctx.fillStyle='rgba(250,252,249,.88)';for(const f of flakes){f.y+=f.v*dt;f.x+=Math.sin(time+f.p)*12*dt;if(f.y>h+8){f.y=-8;f.x=rnd()*w;}ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fill();}
      } else if(state.weather==='wind'||state.weather==='clear'||state.weather==='hot'){
        for(const l of leaves){l.x+=dt*(state.weather==='wind'?58:20);l.y+=Math.sin(time+l.p)*dt*12;if(l.x>w+15){l.x=-15;l.y=rnd()*h*.7;}ctx.save();ctx.translate(l.x,l.y);ctx.rotate(l.p+time*.4);ctx.fillStyle='rgba(191,117,66,.65)';ctx.beginPath();ctx.ellipse(0,0, l.s, l.s*.48,0,0,Math.PI*2);ctx.fill();ctx.restore();}
      }
      if(state.weather==='fog'||state.weather==='rain'||state.weather==='storm'){
        for(const m of mist){m.x+=dt*(state.weather==='fog'?7:13)*m.s;if(m.x>w+120)m.x=-120;const y=m.y+Math.sin(time*.3+m.s)*h*.012;const mg=ctx.createRadialGradient(m.x,y,2,m.x,y,w*.20);mg.addColorStop(0,`rgba(227,237,231,${m.a*2})`);mg.addColorStop(1,'rgba(227,237,231,0)');ctx.fillStyle=mg;ctx.beginPath();ctx.ellipse(m.x,y,w*.22,h*.035,0,0,Math.PI*2);ctx.fill();}
      }
      if(state.weather==='storm'){ctx.fillStyle=`rgba(220,237,244,${Math.max(0,Math.sin(time*1.8)-.985)*.7})`;ctx.fillRect(0,0,w,h);}
      if(state.weather==='hot'){const heat=ctx.createLinearGradient(0,h*.48,0,h*.78);heat.addColorStop(0,'rgba(255,220,164,0)');heat.addColorStop(.5,'rgba(255,220,164,.10)');heat.addColorStop(1,'rgba(255,220,164,0)');ctx.fillStyle=heat;ctx.fillRect(0,h*.48,w,h*.3);}
      // Ambient weather grade, deliberately applied before the localized house glow.
      if(p.shade){ctx.fillStyle=`rgba(7,20,36,${p.shade})`;ctx.fillRect(0,0,w,h);}
      // Repaint warm apertures over the grade so the house remains welcoming in bad weather.
      house({x:hx,y:hy,s:houseSize},p,time);
    }
    function draw(dt){drawWorld(dt);}
    function loop(now){if(stopped||!visible||document.hidden||!isActive('weather')){raf=0;return;}if(now-last>32){const dt=Math.min(.08,(now-last)/1000||.032);time+=dt;last=now;draw(dt);}raf=requestAnimationFrame(loop);}
    function start(){if(stopped)return;visible=!document.hidden;if(reduced){draw(0);return;}if(visible&&!raf){last=0;raf=requestAnimationFrame(loop);}}
    function setState(next){state=next||state;draw(0);if(!reduced)start();}
    function visibility(){visible=!document.hidden;if(visible)start();else if(raf){cancelAnimationFrame(raf);raf=0;}}
    const observer=typeof ResizeObserver==='function'?new ResizeObserver(resize):null;observer?.observe(canvas);
    window.addEventListener('resize',resize,{passive:true});document.addEventListener('visibilitychange',visibility);
    resize();start();
    return {setState,stop(){stopped=true;if(raf)cancelAnimationFrame(raf);observer?.disconnect();window.removeEventListener('resize',resize);document.removeEventListener('visibilitychange',visibility);}};
  }

  function activateWeather(){
    const view=mount('weather');if(!view)return;
    styles();const screen=screenElement();view.root.replaceChildren(screen);
    let renderer;try{renderer=createRenderer(screen.querySelector('canvas'));}catch(e){console.error('[LIVE // EARTH] Weather renderer failed.',e);}
    const dock=document.getElementById('le-feature-dock');
    function syncDock(){
      if(!dock||dock.hidden||getComputedStyle(dock).display==='none'){screen.style.removeProperty('--le-weather-dock-clearance');return;}
      const dr=dock.getBoundingClientRect(),sr=screen.getBoundingClientRect();if(dr.width&&dr.height)screen.style.setProperty('--le-weather-dock-clearance',`${Math.ceil(Math.max(0,sr.bottom-dr.top)+14)}px`);
    }
    const dockObserver=dock&&typeof ResizeObserver==='function'?new ResizeObserver(syncDock):null;dockObserver?.observe(dock);
    window.addEventListener('resize',syncDock,{passive:true});window.addEventListener('orientationchange',syncDock,{passive:true});syncDock();

    let abort=null,poll=0,refresh=0,clock=0,disposed=false,serial=0,lastFetch=0,manual=false;
    const select=screen.querySelector('#le-wx-scene-select');
    const stopPoll=()=>{if(poll)clearInterval(poll);poll=0;};
    function paint(data,preview=false){
      const s=parse(data),c=s.current,d=s.daily;renderer?.setState(s);
      setText(screen,'temp',num(c.temperature_2m)===null?'—':String(Math.round(c.temperature_2m)));
      setText(screen,'condition',s.weather==='hot'?'Heat over the valley':s.weather==='wind'?'Wind through the trees':s.weather==='night'?'Night at the mountain house':LABELS[s.code]||'Weather conditions');
      setText(screen,'feels',num(c.apparent_temperature)===null?'':`Feels like ${Math.round(c.apparent_temperature)}°`);
      const hi=num(d.temperature_2m_max?.[0]),lo=num(d.temperature_2m_min?.[0]);setText(screen,'range',`${hi===null?'—':Math.round(hi)+'°'} / ${lo===null?'—':Math.round(lo)+'°'}`);
      const rain=num(d.precipitation_probability_max?.[0]);setText(screen,'rain',rain===null?'—':`${Math.round(rain)}%`);
      const wind=num(c.wind_speed_10m);setText(screen,'wind',wind===null?'—':`${compass(c.wind_direction_10m)} ${Math.round(wind)} km/h`);
      const humidity=num(c.relative_humidity_2m);setText(screen,'humidity',humidity===null?'—':`${Math.round(humidity)}%`);
      setText(screen,'date',formatDate(c.time));screen.dataset.preview=preview?'true':'false';lastFetch=Date.now();
    }
    function preview(kind,message){paint(sample(kind),true);setText(screen,'place','SCENE PREVIEW');setText(screen,'status',message);}
    function locationOff(){preview('clear','LOCATION OFF · Sample values, not a live forecast.');}
    async function fetchLive(){
      if(disposed||!isActive('weather')||manual)return;
      if(window.liveEarthLocationAllowed?.()!==true){locationOff();return;}
      if(navigator.onLine===false){preview('clear','OFFLINE · Sample scene, not live conditions.');return;}
      const point=globe()?.getLocation?.(),lat=Number(point?.latitude),lon=Number(point?.longitude);
      if(!Number.isFinite(lat)||lat < -90||lat>90||!Number.isFinite(lon)||lon < -180||lon>180)return;
      abort?.abort();const controller=new AbortController();abort=controller;const id=++serial;
      const query=new URLSearchParams({latitude:String(lat),longitude:String(lon),current:'temperature_2m,apparent_temperature,is_day,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,relative_humidity_2m',daily:'temperature_2m_max,temperature_2m_min,precipitation_probability_max',forecast_days:'1',timezone:'auto',wind_speed_unit:'kmh',temperature_unit:'celsius',precipitation_unit:'mm'});
      const timeout=setTimeout(()=>controller.abort(),16000);
      try{
        const response=await fetch(`${API}?${query}`,{mode:'cors',credentials:'omit',cache:'no-store',signal:controller.signal});if(!response.ok)throw new Error(`Weather source ${response.status}`);
        const data=await response.json();if(disposed||!isActive('weather')||id!==serial||window.liveEarthLocationAllowed?.()!==true)return;
        paint(data,false);setText(screen,'place','YOUR LOCATION');setText(screen,'status','LIVE CONDITIONS · OPEN-METEO');
      }catch(error){if(error?.name!=='AbortError'&&!disposed&&isActive('weather'))preview('clear','LIVE DATA UNAVAILABLE · Labelled sample scene.');}
      finally{clearTimeout(timeout);if(abort===controller)abort=null;}
    }
    function pollForFix(){
      stopPoll();let tries=24;poll=setInterval(()=>{if(disposed||!isActive('weather')){stopPoll();return;}if(window.liveEarthLocationAllowed?.()!==true){stopPoll();locationOff();return;}
        const p=globe()?.getLocation?.();if(p&&Number.isFinite(Number(p.latitude))&&Number.isFinite(Number(p.longitude))){stopPoll();fetchLive();return;}if(--tries<=0){stopPoll();preview('clear','WAITING FOR LOCATION · No fresh fix yet.');}},500);
    }
    function choose(mode){
      manual=mode!=='auto';if(mode==='auto'){if(window.liveEarthLocationAllowed?.()===true)fetchLive();else locationOff();return;}
      stopPoll();serial++;abort?.abort();abort=null;preview(mode,`PREVIEW · ${mode.toUpperCase()} · SAMPLE VALUES, NOT A LIVE FORECAST.`);
    }
    function onLocation(event){if(!isActive('weather'))return;if(event.detail?.enabled===true&&window.liveEarthLocationAllowed?.()===true&&!manual)pollForFix();else if(window.liveEarthLocationAllowed?.()!==true&&!manual){stopPoll();serial++;abort?.abort();locationOff();}}
    function onStop(){stopPoll();serial++;abort?.abort();if(!manual)locationOff();}
    function onOnline(){if(!manual&&window.liveEarthLocationAllowed?.()===true)pollForFix();}
    function onOffline(){stopPoll();serial++;abort?.abort();if(!manual)preview('clear','OFFLINE · Sample scene, not live conditions.');}
    function onVisibility(){if(!document.hidden&&!manual&&window.liveEarthLocationAllowed?.()===true&&Date.now()-lastFetch>REFRESH_MS)fetchLive();}
    function updateClock(){if(screen.isConnected&&screen.dataset.preview==='true')setText(screen,'date',formatDate());}
    const onModeChange=()=>choose(select.value);
    select.addEventListener('change',onModeChange);window.addEventListener('live-earth-location-state',onLocation);window.addEventListener('live-earth-location-stop',onStop);
    window.addEventListener('online',onOnline);window.addEventListener('offline',onOffline);document.addEventListener('visibilitychange',onVisibility);
    refresh=setInterval(()=>{if(!disposed&&!document.hidden&&!manual&&window.liveEarthLocationAllowed?.()===true)fetchLive();},REFRESH_MS);
    clock=setInterval(updateClock,30000);updateClock();if(window.liveEarthLocationAllowed?.()===true)pollForFix();else locationOff();
    return ()=>{
      disposed=true;serial++;stopPoll();clearInterval(refresh);clearInterval(clock);abort?.abort();renderer?.stop();
      select.removeEventListener('change',onModeChange);window.removeEventListener('live-earth-location-state',onLocation);window.removeEventListener('live-earth-location-stop',onStop);
      window.removeEventListener('online',onOnline);window.removeEventListener('offline',onOffline);document.removeEventListener('visibilitychange',onVisibility);
      dockObserver?.disconnect();window.removeEventListener('resize',syncDock);window.removeEventListener('orientationchange',syncDock);
      screen.remove();document.getElementById(STYLE_ID)?.remove();
    };
  }
  runtime.registerFeature('weather',activateWeather);
})();
