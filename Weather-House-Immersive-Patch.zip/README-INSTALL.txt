# Weather House Scene patch

Target: `Weather/weather-view.js` on `main` (baseline inspected: commit `c450cd4cabf43a5ef26df034ebbf67118c9ed17b`).

This patch replaces only the Weather feature renderer. It keeps the existing Stacks registration/mount contract, weather scene selector values, Open-Meteo fields and 15-minute refresh, explicit location permission boundary, sample/offline labels, shared dock clearance, and teardown behaviour.

The new scene is a full-screen responsive illustrated Japanese mountain house beside a lake. Window shoji, doorway lantern and local warm spill respond to weather: strongest in rain/storm/snow/fog/night, subdued in clear daylight. Rain, snow, wind-blown leaves, fog, night sky, snow caps and water reflections are drawn in Canvas 2D. It does not add Three.js or modify Earth/Moon/Sun.

Install by replacing `Weather/weather-view.js` with the file in this archive. No other files are changed. Test the scene selector in AUTO, CLEAR, CLOUDY, RAIN, STORM, SNOW, FOG, WIND, HEAT and NIGHT, then test live weather with the app's existing location permission enabled.
